import moment from "moment";
export class Moment {

}
