import { fas } from "@fortawesome/free-solid-svg-icons";
import { faInstagram, faTwitter } from "@fortawesome/free-brands-svg-icons";
import FontAwesomeIcon from "@/assets/libs/FontAwesomeIcon.vue";
import { library } from "@fortawesome/fontawesome-svg-core";

library.add(fas, faTwitter, faInstagram);

export { FontAwesomeIcon };
