<template>
  <div class="">
    <Tools />
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";
import Tools from "@/components/protected/Tools.vue"; // @ is an alias to /src

export default defineComponent({
  name: "ToolsPage",
  components: {
    Tools,
  },
});
</script>
