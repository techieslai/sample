<template>
  <div>
    <Header @menu="openSideMenu" :refresh="hRefresh" />
    <transition name="sm-fade">
      <SideNav
        :title="sideNavTitle"
        @close="isSideNavOpen = false"
        v-if="isSideNavOpen"
        @hRefresh="refreshHeader"
        :role="userRole"
      />
    </transition>

    <div class="page-wrapper" @click="isSideNavOpen = false;">
      <transition name="msg-fade">
        <Alert
          :title="alertTitle"
          @close="isAlertOpen = false"
          v-if="isAlertOpen"
        >
          <template v-slot:message>
            <span class="msg"> {{ alertDesc || "" }}</span>
          </template>
        </Alert>
      </transition>
      <router-view @alert="openAlert" @hRefresh="refreshHeader"></router-view>
    </div>
    <Footer />
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from "vue";
import Header from "@/components/common/Header.vue"; // @ is an alias to /src
import Footer from "@/components/common/Footer.vue"; // @ is an alias to /src
import SideNav from "@/components/common/SideNav.vue"; // @ is an alias to /src
import Alert from "@/components/common/Alert.vue"; // @ is an alias to /src

export default defineComponent({
  name: "Page",
  components: {
    Header,
    Footer,
    SideNav,
    Alert,
  },

  setup() {
    const isSideNavOpen = ref(false);
    const sideNavTitle = ref("");
    const userRole = ref("");
    const hRefresh = ref("");
    hRefresh.value = Date();

    const isAlertOpen = ref(true);
    const alertTitle = ref("");
    const alertDesc = ref("");

    const openSideMenu = (title: any, role: any) => {
      isSideNavOpen.value = true;
      sideNavTitle.value = title;
      userRole.value = role;
    };

    const refreshHeader = () => {
      hRefresh.value = Date();
    };
    const openAlert = (title: any, message: any) => {
      alertTitle.value = title;
      alertDesc.value = message;
      if (alertTitle.value != "") {
        isAlertOpen.value = true;
        let timer = 5000;
        setTimeout(() => {
          isAlertOpen.value = false;
        }, timer);
      } else {
        isAlertOpen.value = false;
      }
    };
    if (alertTitle.value != "") {
      isAlertOpen.value = true;
    } else {
      isAlertOpen.value = false;
    }

    const closeAlert = () => {
      isAlertOpen.value = false;
    };

    return {
      isSideNavOpen,
      openSideMenu,
      sideNavTitle,
      openAlert,
      alertTitle,
      alertDesc,
      isAlertOpen,
      refreshHeader,
      hRefresh,
      userRole,
      closeAlert,
    };
  },
});
</script>

<style lang="scss">
.sm-fade-enter-active,
.sm-fade-leave-active {
  transition: all 2s ease;
}
.sm-fade-enter-from {
  opacity: 90%;
  transform: translateX(-100%);
}
.sm-fade-leave-to {
  opacity: 50%;
  transform: translateX(-100%);
}

//alert Transition
.msg-fade-enter-active,
.msg-leave-active {
  transition: all 0.65s ease;
}
.msg-fade-enter-from {
  opacity: 80%;
  transform: translateY(-100%);
}
.msg-fade-leave-to {
  opacity: 30%;
  transform: translateY(-100%);
}
</style>

