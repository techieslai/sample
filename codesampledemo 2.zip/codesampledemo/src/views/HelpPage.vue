<template>
  <div class="">
    <Help />
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";
import Help from "@/components/Help.vue"; // @ is an alias to /src

export default defineComponent({
  name: "HelpPage",
  components: {
    Help,
  },
});
</script>
