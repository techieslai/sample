<template>
  <div class="">
    <Features />
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";
import Features from "@/components/Features.vue"; // @ is an alias to /src

export default defineComponent({
  name: "FeaturesPage",
  components: {
    Features,
  },
});
</script>
