<template>
  <div class="">
    <Explore />
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";
import Explore from "@/components/Explore.vue"; // @ is an alias to /src

export default defineComponent({
  name: "ExplorePage",
  components: {
    Explore,
  },
});
</script>
