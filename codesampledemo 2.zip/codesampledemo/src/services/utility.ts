import { DATA_DICTIONARY } from "@/data/dictionary";

export class Utility {
  getDatasetByKeyVal(dset: any, key: string, val: string) {
    let result: any = [];
    dset.forEach((element: any) => {
      if (element.hasOwnProperty(key) && element[key] === val) {
        result.push(element);
      }
    });
    return result[0];
  }

  getRandomColor(brightness: number) {
    // Six levels of brightness from 0 to 5, 0 being the darkest
    var rgb = [Math.random() * 256, Math.random() * 256, Math.random() * 256];
    var mix = [brightness * 51, brightness * 51, brightness * 51]; //51 => 255/5
    var mixedrgb = [rgb[0] + mix[0], rgb[1] + mix[1], rgb[2] + mix[2]].map(
      function (x) {
        return Math.round(x / 2.0);
      }
    );
    return "rgb(" + mixedrgb.join(",") + ")";
  }
  getRandomLightColor() {
    var letters = "0123456789ABCDEF";
    var color = "#";
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }
  getRandomDarkColor() {
    var letters = "0123456789ABCDEF";
    var color = "#";
    for (var i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }

  gerRandomNumber(digits: number) {
    var letters = "0123456789";
    var num = "";
    for (var i = 0; i < digits; i++) {
      num += letters[Math.floor(Math.random() * 10)];
    }
    return num;
  }

  stringShift(str: string, shift?: number) {
    let strCopy = "";
    for (let i = 0; i < str.length; i++) {
      let ind: number = str[i].charCodeAt(0) + (shift || 0);
      strCopy = strCopy + String.fromCharCode(ind);
    }
    strCopy = strCopy.replaceAll("@", "Z");
    strCopy = strCopy.replaceAll("`", "z");
    strCopy = strCopy.replaceAll("/", "9");
    strCopy = strCopy.replaceAll("{", "a");
    strCopy = strCopy.replaceAll("[", "A");
    strCopy = strCopy.replaceAll(":", "0");
    // strCopy = str.replaceAll("[", "Z");
    // strCopy = str.replaceAll("/", "Z");
    return strCopy;
  }
  stringReverse(str: string) {
    return str.split("").reverse().join("");
  }
  stringClean(str: string, change?: string, clean?: boolean) {
    str = str.replaceAll(" ", "");
    if (clean) {
      str = str.replaceAll("@", "");
      str = str.replaceAll("_", "");
      str = str.replaceAll("'", "");
      str = str.replaceAll("/", "");
      str = str.replaceAll("-", "");
      str = str.replaceAll(".", "");
    }
    if (change === "U") {
      return str.toUpperCase();
    }
    if (change === "L") {
      return str.toLowerCase();
    }
    return str;
  }

  filterDisctionary = (filter: string) => {
    let dict: any[] = DATA_DICTIONARY;
    const d = dict.filter((e: any) => {
      if (e["attribute"].toUpperCase() === filter.toUpperCase())
        return e["attribute"].toUpperCase() === filter.toUpperCase();
    });
    return d;
  };

  dictionary = (table: string, cols: any[]) => {
    let dict = new Array();
    let dict_filter = new Array();
    let val: any;
    cols.forEach((col: any) => {
      val = col;
      let d = this.filterDisctionary(table + "." + col);
      if (d.length > 0) {
        val = d[0];
        console.log("table");
        console.log(val);
      } else {
        let d = this.filterDisctionary(col);
        if (d.length > 0) {
          val = d[0];
          console.log("cmn");
        } else {
          val = this.titleCase(col);
          val = {
            attribute: col,
            config: {
              title: val,
              data_type: "text",
              control_type: "text",
              type: "normal",
              length: 100,
              icon: "text",
            },
          };
        }
      }
      val["attribute"] = col;
      dict.push(val);
    });
    return dict;
  };
  titleCase(string: string) {
    string = string.replaceAll("_", " ");
    let sentence = string.toLowerCase().split(" ");
    for (var i = 0; i < sentence.length; i++) {
      sentence[i] = sentence[i][0].toUpperCase() + sentence[i].slice(1);
    }
    sentence.join(" ");
    return sentence[0];
  }

  //Exact Match Filter
  arrayFilterMatch(array: any[], filters: any) {
    return array.filter((o) =>
      Object.keys(filters).every((k) =>
        [].concat(filters[k]).every((v) => {
          if (o) {
            try {
              if (o[k] === v) return true;
            } catch {
              return false;
            }
          } else {
            return false;
          }
        })
      )
    );
  }
  //Pattern Match Filter
  arrayFilterPatternMatchOld(array: any[], str: string) {
    let filter: any = {};
    Object.keys(array[0]).forEach((o: any) => {
      filter[o] = str;
    });
    return array.filter((o) =>
      Object.keys(filter).every((k: any) => {
        console.log(filter[k]);
        let x = [].concat(filter[k]).every((v) => {
          // try {
          let pattern = v;
          let key = o[k];
          console.log("patt-" + pattern);
          console.log("val-" + key);
          if (key.includes(pattern)) {
            console.log(key + " includes " + pattern);
            return true;
          }
          // } catch {
          //   return false;
          // }
        });
        console.log(x);
      })
    );
  }

  arraySort(array: any[], property: string, desc: boolean) {
    let direction = desc ? -1 : 1;
    array.sort(function compare(a, b) {
      let comparison = 0;
      if (a[property] > b[property]) {
        comparison = 1 * direction;
      } else if (a[property] < b[property]) {
        comparison = -1 * direction;
      }
      return comparison;
    });
    return array;
  }
  arrayFilterPatternMatch(array: any[], str: string) {
    return array.filter((o: any) => {
      let result = false;
      Object.keys(o).forEach((el: any) => {
        if (o[el]) {
          if (o[el].includes(str)) result = true;
        }
      });
      return result;
    });
  }

  //Distinct Values
  arrayGetDistinctValues(array: any[], skey: string): any {
    // skey = Category
    let results = new Array();
    array.forEach((obj) => {
      if (obj.hasOwnProperty(skey)) {
        let value = obj[skey];
        results.push(value);
      }
    });
    return results.filter((elem, i, arr) => {
      if (arr.indexOf(elem) === i) {
        return elem;
      }
    });
  }

  //Search Key Value
  arrayFilterSerchKeyValues(array: any[], key: string, value: string): any {
    let results = new Array();
    array.forEach((obj) => {
      Object.keys(obj).forEach((filter) => {
        if (filter === key && obj[filter] === value) {
          results.push(obj);
        }
      });
    });
    return results.filter((elem, i, arr) => {
      if (arr.indexOf(elem) === i) {
        return elem;
      }
    });
  }

  //Search Key Value
  arrayInitialize(length: number): any {
    let results = new Array();
    let array = Array(length)
      .fill(null)
      .map((_, index) => {
        return { coin: index };
      });
    results = array;
    return results;
  }

  //Randomize the Array
  arrayRandomize(array: any): any {
    let results = new Array();
    for (let i = 0; i <= array.length - 1; i++) {
      let rndPos = this.randomIntFromInterval(i, array.length - 1);
      results.push(array[rndPos]);
      array[rndPos]=array[i];
    }
    return results;
  }

  randomIntFromInterval(min: number, max: number) {
    // min and max included
    return Math.floor(Math.random() * (max - min + 1) + min);
  }

  // //Pattern Match Filter
  // arrayFilterPatternMatch(array: any[], str: string) {
  //   let filter: any = {};
  //   Object.keys(array[0]).forEach((o: any) => {
  //     filter[o] = str;
  //   });
  //   return array.filter((o) => {
  //     Object.keys(filter).every((k: any) => {
  //       let pattern = str;
  //       let key = o[k];
  //       if (key.includes(pattern)) return true;
  //     });
  //   });
  // }
}
