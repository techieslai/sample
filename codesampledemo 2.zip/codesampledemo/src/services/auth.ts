import { toRefs, reactive, resolveComponent } from "vue";
import { FIREBASE_CONFIG } from "@/data/k-tools";
import firebase from "firebase/app";
// Required for side-effects
import "firebase/auth";
import "firebase/database";
import "firebase/firestore";
import "firebase/storage";
import { AUTH_USER } from "@/data/settings";

// initialize firebase, this is directly from the firebase documentation
// regarding getting started for the web

const fdb = !firebase.apps.length
  ? firebase.initializeApp(FIREBASE_CONFIG)
  : firebase.app();

const state = reactive<{ user: any; initialized: boolean; error: any }>({
  user: null,
  initialized: false,
  error: null,
});

export default function () {
  const login = (email: string, password: string) => {
    localStorage.removeItem(AUTH_USER);
    return fdb
      .auth()
      .signInWithEmailAndPassword(email, password)
      .then(
        (user) => {
          state.user = user;
          state.error = null;
          localStorage.setItem(AUTH_USER, state.user);
          return user;
        },
        (error) => {
          state.error = error;
          throw error;
        }
      );
  };

  const register = (name: string, email: string, password: string) => {
    return fdb
      .auth()
      .createUserWithEmailAndPassword(email, password)
      .then(
        (user) => {
          state.user = user;
          state.error = null;
          authCheck();
          return user;
        },
        (error) => {
          state.error = error;
          throw error;
        }
      );
  };

  const logoutUser = () => {
    localStorage.removeItem(AUTH_USER);
    return fdb
      .auth()
      .signOut()
      .then(() => {
        state.user = null;
      });
  };

  const resetPassword = (email: string) => {
    return fdb
      .auth()
      .sendPasswordResetEmail(email)
      .then(
        (user) => {
          state.user = user;
          state.error = null;
          return user;
        },
        (error) => {
          state.error = error;
          throw error;
        }
      );
  };

  // RUN AT STARTUP
  const authCheck = () => {
    return new Promise((resolve, reject) => {
      !state.initialized &&
        fdb.auth().onAuthStateChanged(async (_user) => {
          if (_user) {
            state.user = _user;
          } else {
            state.user = null;
            localStorage.removeItem(AUTH_USER);
          }
          state.initialized = true;
          console.log(_user);
          resolve(true);
        });
    });
  };

  return {
    ...toRefs(state),
    // FUNCTIONS
    login,
    logoutUser,
    authCheck,
    register,
    resetPassword,
  };
}
