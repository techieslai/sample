import { reactive, ref } from "vue";
import { FIREBASE_CONFIG } from "@/data/k-tools";
import firebase from "firebase/app";
// Required for side-effects
import "firebase/auth";
import "firebase/database";
import "firebase/firestore";
import "firebase/storage";
import { AUTH_USER } from "@/data/settings";
import { Utility } from "./utility";
import store from "@/store";

export class FDBUtility {
  fdb = !firebase.apps.length
    ? firebase.initializeApp(FIREBASE_CONFIG)
    : firebase.app();

  db = ref();
  readdb = ref();
  data = ref();
  user = ref();
  constructor(collection: string, common?: boolean) {
    let filter = common || true;
    this.user.value = store.getters.profile.email || "";
    if (filter && this.user.value != "") {
      this.readdb.value = this.fdb
        .firestore()
        .collection(collection)
        .where("insert_user", "==", this.user.value);
    } else {
      this.readdb.value = this.fdb.firestore().collection(collection);
    }
    this.db.value = this.fdb.firestore().collection(collection);
  }
  async getAll() {
    this.data.value = new Array();
    const snapshot = await this.readdb.value.get();
    snapshot.forEach((res: any) => {
      let item = res.data();
      item["doc_id"] = res.id;
      this.data.value.push(item);
    });
    return this.data.value;
  }
  async getbyKeyVal(key: string, val: string) {
    this.data.value = new Array();
    const snapshot = await this.readdb.value.get();
    snapshot.forEach((res: any) => {
      let item = res.data();
      item["doc_id"] = res.id;
      if (item[key] === val) this.data.value.push(item);
    });
    return this.data.value;
  }
  async add(payload: any) {
    payload["insert_dt"] = Date();
    payload["insert_user"] =
      store.getters.profile.email === ""
        ? payload["email"]
        : store.getters.profile.email;
    const response = await this.db.value
      .add(payload)
      .then((res: any) => {
        return res;
      })
      .catch((error: any) => {
        return error;
      });
  }
  async update(id: any, payload: any) {
    payload["update_dt"] = Date();
    payload["update_user"] = store.getters.profile.email;
    delete payload.doc_id;
    const response = await this.db.value
      .doc(id)
      .update(payload)
      .then((res: any) => {
        return res;
      })
      .catch((error: any) => {
        return error;
      });
  }
  async set(payload: any) {
    const response = await this.db.value(payload);
  }
  order(obj: any) {
    Object.keys(obj).forEach((k: any) => {
      const v = obj[k];
      delete obj[k];
      obj[k] = v;
    });
  }
  audit() {
    return {
      updated_on: Date(),
      updated_by: store.getters.user["email"],
    };
  }
  async delete(id: any) {
    const response = await this.db.value
      .doc(id)
      .delete()
      .then((res: any) => {
        return res;
      })
      .catch((error: any) => {
        return error;
      });
  }
}
