import { API_URL } from "@/data/settings";
import axios from "axios";

axios;

export class APIUtility {
  getDataUser: any = async () => {
    let data = {
      data: [
        { id: 1, firstname: "Suresh", lastname: "Kotinadhuni" },
        { id: 2, firstname: "Hasini", lastname: "Kotinadhuni" },
        { id: 3, firstname: "Ganga", lastname: "Tadisetti" },
        { id: 4, firstname: "Nitin", lastname: "Kotinadhuni" },
        { id: 5, firstname: "Aruna", lastname: "Kasa" },
        { id: 6, firstname: "Sunitha", lastname: "Boppe" },
        { id: 7, firstname: "Sudhakar", lastname: "Kotinadhuni" },
      ],
    };
    let x = await data;
    return <any>x;
  };

  getData: any = async (): Promise<any> => {
    const { data } = await axios.get(API_URL + "persons?_quantity=20");
    return data;
  };


}
