import { DATASET } from "@/data/mappings";

export class Validation {
  RuleConfig = [
    {
      key: "REQUIRED",
      rule: "'@'.length === 0",
      message: "@ is required",
    },
    {
      key: "MIN",
      rule: "'@'.length < #1",
      message: "@ should be more than #1 characters",
    },
    {
      key: "MAX",
      rule: "'@'.length > #1",
      message: "@ should be less than #1 characters",
    },
    {
      key: "EMAIL",
      rule: "'@'.length > #1",
      reg_exp:
        "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:.[a-zA-Z0-9-]+)*$",
      message: "@ is not valid",
    },
  ];
  constructor() {}

  getRule(key: string, val: string) {
    let dset = this.RuleConfig;
    let result: any = [];
    dset.forEach((element: any) => {
      if (element.hasOwnProperty(key) && element[key] === val) {
        result.push(element);
      }
    });
    return result[0];
  }

  replaceParams(str: string, params: any): any {
    for (let i = 1; i <= 10; i++) str = str.replaceAll("#" + i, params[i]);
    return str;
  }

  validatePayload(payload: any, ruleSet: any) {
    let errors = new Array();
    let msgs: any = new Array();
    Object.keys(ruleSet).forEach((attr) => {
      let ruleSetList = ruleSet[attr];
      let rulesArray = ruleSetList["rules"];
      let attrDesc = ruleSetList["description"];
      rulesArray.forEach((r: any) => {
        let rule_key = r.split("-");
        let rCfgRule = this.getRule("key", rule_key[0]);
        let rCfgExp = rCfgRule["reg_exp"] || "";
        let rSetRule = rCfgRule["rule"].replaceAll("@", payload[attr]);
        rSetRule = this.replaceParams(rSetRule, rule_key);
        let msg = rCfgRule["message"];
        msg = this.replaceParams(msg, rule_key);
        msg = msg.replace("@", attrDesc);
        let eResult: any = "Not Evaluated";
        try {
          if (
            rule_key[0] === "REQUIRED" ||
            (rule_key[0] != "REQUIRED" && payload[attr] != "")
          ) {
            if (rCfgExp != "") {
              eResult = payload[attr].match(rCfgExp) ? false : true;
            } else {
              eResult = eval(rSetRule);
            }
            if (!eResult) msg = "";
          } else {
            msg = "";
          }
        } catch {
          eResult = "Failed";
        }
        let err = {
          attr: attr,
          rule: r,
          eval: rSetRule,
          method: rCfgExp != "" ? true : false,
          eval_result: eResult,
          message: msg,
        };
        if (msg != "") {
          errors.push(err);
          msgs.push(msg);
        }
      });
    });
    return {
      errors: errors,
      result: errors.length === 0 ? false : true,
      messages: msgs,
    };
  }
}
