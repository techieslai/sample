<template>
  <div class="main-page">
    <svg id="svg-bg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
      <defs>
        <linearGradient id="gradient" x1="20%" y1="100%" x2="20%" y2="20%">
          <stop offset="0%" stop-color="rgba(67, 183, 191,0.5)" />
          <stop offset="100%" stop-color="rgba(196, 233, 235,0.5)" />
        </linearGradient>
      </defs>
      <path
        id="background"
        d="M0,320L80,298.7C160,277,320,235,480,202.7C640,171,800,149,960,144C1120,139,1280,149,1360,154.7L1440,160L1440,0L1360,0C1280,0,1120,0,960,0C800,0,640,0,480,0C320,0,160,0,80,0L0,0Z"
      ></path>
    </svg>
    <PageContainer />
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";
import PageContainer from "@/views/PageContainer.vue"; // @ is an alias to /src

export default defineComponent({
  name: "Page",
  components: {
    PageContainer,
  },
});
</script>

<style lang="scss">
#app {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.main-page {
  //  background-size: cover;
  // background-repeat: repeat;
  transition: 1s ease-in-out;
  #svg-bg {
    position: absolute;
    top: 0;
    left: 0;
    margin-top: 4em;
    z-index: -100;
    background-repeat: no-repeat;
    background-attachment: fixed;
  }
}
#background {
  fill: url(#gradient);
}
</style>



