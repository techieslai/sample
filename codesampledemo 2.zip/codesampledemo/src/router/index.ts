import store from "@/store";
import { createRouter, createWebHistory, RouteRecordRaw } from "vue-router";
import HomePage from "../views/HomePage.vue";

const routes: Array<RouteRecordRaw> = [
  {
    path: "/",
    name: "HomePage",
    component: HomePage,
  },
  {
    path: "/explore",
    name: "ExplorePage",
    component: () => import("../views/ExplorePage.vue"),
  },
  {
    path: "/features",
    name: "FeaturesPage",
    component: () => import("../views/FeaturesPage.vue"),
  },

  {
    path: "/help",
    name: "HelpPage",
    component: () => import("../views/HelpPage.vue"),
  },

  {
    path: "/login",
    name: "Login",
    component: () => import("@/components/authentication/Login.vue"),
  },
  {
    path: "/register",
    name: "Register",
    component: () => import("@/components/authentication/Register.vue"),
  },
  {
    path: "/forgotpassword",
    name: "ForgotPassword",
    component: () => import("@/components/authentication/ForgotPassword.vue"),
  },

  //Protected Pages
  {
    path: "/changepassword",
    name: "ChangePassword",
    component: () => import("@/components/authentication/ChangePassword.vue"),
  },

  {
    path: "/colors",
    name: "Colors",
    component: () => import("@/components/protected/Colors.vue"),
  },
  {
    path: "/feedback",
    name: "Feedback",
    component: () => import("@/components/protected/Feedback.vue"),
  },
  {
    path: "/dashboard",
    name: "Dashboard",
    component: () => import("@/components/user/Dashboard.vue"),
  },
  {
    path: "/settings",
    name: "Settings",
    component: () => import("@/components/user/Settings.vue"),
  },
  {
    path: "/users",
    name: "Users",
    component: () => import("@/components/admin/Users.vue"),
  },
  {
    path: "/games",
    name: "Games",
    component: () => import("@/components/games/Jumble.vue"),
  },
  {
    path: "/testapi",
    name: "TestApi",
    component: () => import("@/components/test/TestApi.vue"),
  },
  {
    path: "/testdb",
    name: "TestDb",
    component: () => import("@/components/test/TestDb.vue"),
  },
  {
    path: "/template",
    name: "Template",
    component: () => import("@/components/test/Template.vue"),
  },
  {
    path: "/apps/pmanager",
    name: "PassManager",
    component: () => import("@/components/user/apps/keypad/PassManager.vue"),
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

router.beforeEach((to, from, next) => {
  const publicPages = [
    "/",
    "/explore",
    "/features",
    "/help",
    "/login",
    "/register",
    "/forgotpassword",
  ];
  const adminPages = ["/users"];
  const authRequired = !publicPages.includes(to.path);
  const adminRequired = !adminPages.includes(to.path);
  // console.log(store.getters.isLoggedIn);
  // trying to access a restricted page + not logged in
  // redirect to login page
  if (authRequired && !store.getters.isLoggedIn) {
    next("/login");
  } else {
    next();
  }
});

export default router;
