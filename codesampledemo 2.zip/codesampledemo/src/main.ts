import { createApp } from "vue";
import App from "./App.vue";
import "./registerServiceWorker";
import router from "./router";
import store from "./store";
import moment from "moment";
import { FontAwesomeIcon } from "@/assets/plugins/font-awesome";

moment.locale("us");

const app = createApp(App)
  .use(store)
  .use(router)
  .component("fa", FontAwesomeIcon);
app.config.globalProperties.$moment = moment;
app.mount("#app");

//Filters

app.config.globalProperties.$filters = {
  currencyUSD(value: any) {
    return "$" + value;
  },
  timeDate(value: any) {
    return moment(value).format("YYYY-MM-DD");
  },
  timeAgo(value: any) {
    return moment(value).fromNow();
  },
};
