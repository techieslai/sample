<template>
  <div id="wrapper">
    <!-- Menu -->
    <div id="main">
      <article>
        <div class="form-container">
          <!-- <Loader :show="isLoading" type="bar" /> -->
          <div class="form-sm">
            <h1 class="form-title">Forgot Password</h1>
            <form @submit.prevent="submit">
              <Callout :title="cTitle" :msgs="messages" :refresh="key" />
              <div class="control-group">
                <label>Registered Email</label>
                <input
                  type="email"
                  name="email"
                  id="email"
                  class="form-control"
                  placeholder="email@example.com"
                  v-model="payload.email"
                />
              </div>
              <div class="control-group">
                <label
                  >Password change link will be sent to the registered email
                  id</label
                >
              </div>
              <br />
              <a
                name="register"
                id="register"
                class="link-button"
                value="Register"
                @click="
                  key = key + 1;
                  forgot();
                "
                >Reset</a
              >
            </form>
            <br />
            <p>
              <router-link to="/forgotpassword" class="login-link"
                >Forgot password?</router-link
              >
              <br />
              Don't have an account?
              <router-link to="/register" class="login-link"
                >Register here</router-link
              >
            </p>
          </div>
        </div>
      </article>
    </div>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import { defineComponent, reactive, ref } from "vue";
import Callout from "@/components/common/Callout.vue";
import Loader from "@/components/common/Loader.vue";
import { useStore } from "vuex";
import { Validation } from "@/services/validation";
import router from "@/router";

export default defineComponent({
  name: "Login",
  components: { Callout, Loader },
  emits: ["alert", "hRefresh"],

  setup(_, { emit }) {
    interface pyld {
      email: string;
      password: string;
      rememberMe: boolean;
    }
    const payload = reactive(<pyld>{});
    const store = useStore();
    const result = ref({});
    const cTitle = ref();
    const messages = ref();
    const key = ref(0);
    const isLoading = ref(false);
    cTitle.value = "Input Errors";
    messages.value = [];
    const forgot = async () => {
      isLoading.value = true;
      messages.value = [];
      let vldn: any = validateForm();
      if (vldn.result) {
        cTitle.value = "Input Errors";
        messages.value = vldn.messages;
      } else {
        try {
          result.value = await store.dispatch("forgotpassword", payload);
          emit("hRefresh");
          isLoading.value = false;
        } catch (e: any) {
          //emit("alert", "Error", e.message);
          messages.value = [e.message];
          isLoading.value = false;
        }
      }
    };

    const logout = async () => {
      result.value = await store.dispatch("logout");
      emit("hRefresh");
    };

    const setDefaults = () => {
      logout();
      payload.email = "";
    };

    const validateForm = () => {
      let vldn = new Validation();
      const rules = {
        email: { rules: ["REQUIRED", "EMAIL"], description: "E-Mail" },
      };
      return vldn.validatePayload(payload, rules);
    };

    setDefaults();
    return {
      payload,
      forgot,
      isLoading,
      setDefaults,
      messages,
      key,
      cTitle,
    };
  },
});
</script>
