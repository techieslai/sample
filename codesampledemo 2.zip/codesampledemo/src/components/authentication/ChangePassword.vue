<template>
  <div id="wrapper">
    <!-- Menu -->
    <div id="main">
      <article>
        <div class="form-container">
          <!-- <Loader :show="isLoading" type="bar" /> -->
          <div class="form-sm">
            <h1 class="form-title">Change Password</h1>
            <form @submit.prevent="submit">
              <Callout :title="cTitle" :msgs="messages" :refresh="key" />
              <!-- <div class="control-group">
                <label>Name</label>
                <input
                  type="text"
                  name="fname"
                  id="fname"
                  class="form-control"
                  placeholder="full name"
                  v-model="payload.fname"
                />
              </div> -->
              <div class="control-group">
                <label>Email</label>
                <span class="form-control">{{ payload.email }}</span>
                <!-- <input
                  type="email"
                  name="email"
                  id="email"
                  class="form-control"
                  placeholder="email@example.com"
                  
                /> -->
              </div>
              <div class="control-group">
                <label>Current Password</label>
                <input
                  type="password"
                  name="password"
                  id="password"
                  class="form-control"
                  placeholder="enter your old password"
                  v-model="payload.password"
                />
              </div>
              <div class="control-group">
                <label>New Password</label>
                <input
                  type="password"
                  name="cpassword"
                  id="cpassword"
                  class="form-control"
                  placeholder="enter a new password"
                  v-model="payload.cpassword"
                />
              </div>
              <div class="control-group">
                <label>Confirm New Password</label>
                <input
                  type="password"
                  name="ccpassword"
                  id="ccpassword"
                  class="form-control"
                  placeholder="confirm new password"
                  v-model="payload.ccpassword"
                />
              </div>
              <br />
              <a
                name="register"
                id="register"
                class="link-button"
                value="Register"
                @click="
                  key = key + 1;
                  changepassword();
                "
                >Save</a
              >
            </form>
            <br />
            <p>
              <router-link to="/forgotpassword" class="login-link"
                >Forgot password?</router-link
              >
              <br />
              Already have an account?
              <router-link to="/login" class="login-link"
                >Login here</router-link
              >
            </p>
          </div>
        </div>
      </article>
    </div>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import { defineComponent, reactive, ref, toRefs } from "vue";
import Callout from "@/components/common/Callout.vue";
import Loader from "@/components/common/Loader.vue";
import { useStore } from "vuex";
import { Validation } from "@/services/validation";
import router from "@/router";

export default defineComponent({
  name: "ChangePassword",
  components: { Callout, Loader },
  emits: ["alert", "hRefresh"],

  setup(_, { emit }) {
    interface pyld {
      email: string;
      password: string;
      cpassword: string;
      ccpassword: string;
      rememberMe: boolean;
    }
    const payload = reactive(<pyld>{});
    const store = useStore();
    const result = ref({});
    const cTitle = ref();
    const messages = ref();
    const key = ref(0);
    const isLoading = ref(false);
    cTitle.value = "Input Errors";
    messages.value = [];

    const register = async () => {
      messages.value = [];
      cTitle.value = "Input Errors";
      if (
        payload.password != "" &&
        payload.cpassword != "" &&
        payload.ccpassword != "" &&
        payload.cpassword === payload.ccpassword
      ) {
        isLoading.value = true;
        let vldn: any = validateForm();
        if (vldn.result) {
          messages.value = vldn.messages;
        } else {
          try {
            result.value = await store.dispatch("changepassword", payload);
            emit("alert", "Confirmation", "Password changed successfully");
            emit("hRefresh");
            router.push("/login");
            isLoading.value = false;
          } catch (e: any) {
            emit("alert", "Error", e.message);
            messages.value = [e.message];
            isLoading.value = false;
          }
        }
      } else {
        messages.value = ["Passwords are empty or didn't match"];
        //emit("alert", "Error", );
      }
    };

    const setDefaults = () => {
      payload.email = store.getters.profile["email"];
      payload.password = "";
      payload.cpassword = "";
      payload.ccpassword = "";
      payload.rememberMe = false;
    };

    const validateForm = () => {
      let vldn = new Validation();
      const rules = {
        email: { rules: ["REQUIRED", "EMAIL"], description: "E-Mail" },
        password: {
          rules: ["REQUIRED", "MIN-6", "MAX-15"],
          description: "Password",
        },
        cpassword: {
          rules: ["REQUIRED", "MIN-6", "MAX-15"],
          description: "Password",
        },
        ccpassword: {
          rules: ["REQUIRED", "MIN-6", "MAX-15"],
          description: "Password",
        },
      };
      return vldn.validatePayload(payload, rules);
    };
    setDefaults();
    return {
      payload,
      register,
      isLoading,
      setDefaults,
      messages,
      key,
      cTitle,
    };
  },
});
</script>
