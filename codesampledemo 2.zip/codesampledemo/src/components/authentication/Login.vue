<template>
  <div id="wrapper">
    <!-- Menu -->
    <div id="main">
      <article>
        <div class="form-container">
          <!-- <Loader :show="isLoading" type="bar" /> -->
          <div class="form-sm">
            <h1 class="form-title">Login</h1>
            <form @submit.prevent="submit">
              <Callout
                :title="errTitle"
                :msgs="errMsgs"
                :refresh="refresh_key"
              />
              <div class="control-group">
                <label>Email</label>
                <input
                  type="email"
                  name="email"
                  id="email"
                  class="form-control"
                  placeholder="email@example.com"
                  v-model="payload.email"
                />
              </div>
              <div class="control-group">
                <label>Password</label>
                <input
                  type="password"
                  name="password"
                  id="password"
                  class="form-control"
                  placeholder="enter your password"
                  v-model="payload.password"
                />
              </div>
              <br />
              <a
                name="register"
                id="register"
                class="link-button"
                value="Register"
                @click="
                  key = key + 1;
                  login();
                "
                >Login</a
              >
            </form>
            <br />
            <p>
              <router-link to="/forgotpassword" class="login-link"
                >Forgot password?</router-link
              >
              <br />
              Don't have an account?
              <router-link to="/register" class="login-link"
                >Register here</router-link
              >
            </p>
          </div>
        </div>
      </article>
    </div>
  </div>
</template>

<script lang="ts">
// @ts-ignore
import { defineComponent, reactive, ref } from "vue";
import Callout from "@/components/common/Callout.vue";
import Loader from "@/components/common/Loader.vue";
import { useStore } from "vuex";
import { Validation } from "@/services/validation";
import router from "@/router";

export default defineComponent({
  name: "Login",
  components: { Callout, Loader },
  emits: ["alert", "hRefresh"],

  setup(_, { emit }) {
    interface pyld {
      email: string;
      password: string;
      rememberMe: boolean;
    }
    const setDefaultPayload = () => {
      logout();
      payload.email = "";
      payload.password = "";
      payload.rememberMe = false;
      errTitle.value = "Input Errors";
      errMsgs.value = new Array();
    };
    const payload = reactive(<pyld>{});
    const store = useStore();
    const response = ref({});
    const errTitle = ref();
    const errMsgs = ref();
    const refresh_key = ref(0);
    const isLoading = ref(false);

    const login = async () => {
      isLoading.value = true;
      let vldnForm: any = validateForm();
      if (vldnForm.result) {
        errMsgs.value = vldnForm.messages;
      } else {
        try {
          response.value = await store.dispatch("login", payload);
          emit("hRefresh");
          router.push("/");
          isLoading.value = false;
        } catch (e: any) {
          //emit("alert", "Error", e.message);
          errMsgs.value = [e.message];
          isLoading.value = false;
        }
      }
      refresh_key.value++;
    };

    const logout = async () => {
      response.value = await store.dispatch("logout");
      router.push("/login");
      emit("hRefresh");
    };

    const validateForm = () => {
      let vldn = new Validation();
      const rules = {
        email: { rules: ["REQUIRED", "EMAIL"], description: "E-Mail" },
        password: {
          rules: ["REQUIRED", "MIN-6", "MAX-15"],
          description: "Password",
        },
      };
      return vldn.validatePayload(payload, rules);
    };

    setDefaultPayload();
    return {
      payload,
      login,
      isLoading,
      errMsgs,
      errTitle,
      refresh_key,
    };
  },
});
</script>
