<template>
  <div id="wrapper">
    <!-- Main -->
    <div id="main">
      <!-- page -->
      <article class="page">
        <header>
          <div class="title">
            <h1>Colors</h1>
            <p>
              This tool is developed for color pallette generator for the SCSS
              file valrables.
            </p>
          </div>
          <div class="meta">
            <time class="published" datetime="2015-11-01"></time>
          </div>
        </header>

        <!-- <footer>
          <ul class="stats">
            <li><a href="#">General</a></li>
            <li><a href="#" class="icon solid fa-heart">28</a></li>
            <li><a href="#" class="icon solid fa-comment">128</a></li>
          </ul>
        </footer> -->

        <section class="tiles">
          <article class="style1">
            <span class="image">
              <img src="images/pic01.jpg" alt="" />
            </span>
            <h2>Pallatte</h2>
            <div class="content1">
              <p>
                This color pallete generates the color variations for the given
                primary color. Please adjust the RGB values below as needed.
              </p>

              R
              <input
                type="text"
                v-model="r"
                @keyup="refresh()"
                style="width: 150px"
              />
              G
              <input
                type="text"
                v-model="g"
                @keyup="refresh()"
                style="width: 150px"
              />
              B
              <input
                type="text"
                v-model="b"
                @keyup="refresh()"
                style="width: 150px"
              />
              <br /><br />
              Color<br />
              <input
                type="text"
                v-model="cname"
                style="width: 200px"
              /><br /><br />
              <div class="">
                <template v-for="(c, index) in colors" :key="c" :index="index">
                  <div class="grid-container-2">
                    <div class="gird-item align-left">
                      <label class="color-tile-text">
                        {{
                          "$" +
                          cname +
                          "-" +
                          (100 * colors.length - index * 100) +
                          ":" +
                          c +
                          "  !default;"
                        }}
                      </label>
                    </div>
                    <div class="gird-item align-center">
                      <div
                        :title="c"
                        class="color-tile"
                        :style="{ backgroundColor: c }"
                      >
                        <label class="light">A</label>
                        <label class="dark">A</label>
                      </div>
                    </div>
                  </div>
                </template>
              </div>
            </div>
          </article>
          <article class="style2 align-center">
            <div class="content">
              <p>Copyright - Suresh Kotinadhuni</p>
            </div>
          </article>
        </section>
      </article>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from "vue";

export default defineComponent({
  name: "Colors",
  props: {
    msg: String,
  },

  setup() {
    let r = ref();
    let g = ref();
    let b = ref();
    let colors = ref();
    let cname = ref();
    colors.value = new Array(9);
    cname.value = "";

    r.value = Math.round(Math.random() * 255) - 100;
    g.value = Math.round(Math.random() * 255) - 100;
    b.value = Math.round(Math.random() * 255) - 100;

    const refresh = () => {
      console.log(r.value);

      let r1: number = parseInt(r.value) < 0 ? 0 : parseInt(r.value);
      let g1: number = parseInt(g.value) < 0 ? 0 : parseInt(g.value);
      let b1: number = parseInt(b.value) < 0 ? 0 : parseInt(b.value);
      let o = 0;
      colors.value[0] = "rgb(" + r1 + "," + g1 + "," + b1 + ")";
      for (let i = 1; i < 9; i++) {
        let vr: number = Math.round((255 - r1) / 4);
        let vg: number = Math.round((255 - g1) / 4);
        let vb: number = Math.round((255 - b1) / 4);
        r1 = r1 + vr;
        g1 = g1 + vg;
        b1 = b1 + vb;
        o = 0;

        let c = "rgb(" + r1 + "," + g1 + "," + b1 + ")";
        colors.value[i] = c;
      }
      console.log(colors.value);
    };

    refresh();

    return {
      colors,
      r,
      g,
      b,
      refresh,
      cname,
    };
  },
});
</script>

<style scoped lang="scss">
.color-tile {
  width: 60px;
  height: 30px;
  display: block;
}
.color-tile-text {
  font-size: 15px;
}

.dark {
  color: $black-800;
}
.light {
  color: $black-200;
}
.bg-light {
  background-color: $black-200;
}
.bg-dark {
  background-color: $black-800;
}
.grid-item {
  border: 1px solid $black-800;
  align-items: center;
  align-content: middle;
}
</style>
