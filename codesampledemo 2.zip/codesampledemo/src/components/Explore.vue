<template>
  <div id="wrapper">
    <!-- Menu -->
    <div id="main">
      <!-- page -->
      <article class="page">
        <header>
          <div class="title">
            <h1>Explore</h1>
            <p>Get familiar with the the Tools</p>
          </div>
          <div class="meta">
            <router-link to="/" class="tool-link"
              ><fa class="icon-sm" icon="home"
            /></router-link>
          </div>
        </header>

        <article>
          <div class="page-grid-12">
            <div id="p-header" class="pg-item left">
              <h2>Tools</h2>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid
                praesentium, cumque quo commodi voluptatum culpa neque pariatur
                perferendis quos? Harum, quasi sunt pariatur cupiditate mollitia
                excepturi distinctio ullam iure tempora?
              </p>
              <InfoBar type="normal" title="Summary">
                <article class="page">
                  <p>
                    Mauris neque quam, fermentum ut nisl vitae, convallis
                    maximus nisl. Sed mattis nunc id lorem euismod placerat.
                    Vivamus porttitor magna enim, ac accumsan tortor cursus at.
                    Phasellus sed ultricies mi non congue ullam corper. Praesent
                    tincidunt sed tellus ut rutrum. Sed vitae justo condimentum,
                    porta lectus vitae, ultricies congue gravida diam non
                    fringilla.
                  </p>
                  <p>
                    Nunc quis dui scelerisque, scelerisque urna ut, dapibus
                    orci. Sed vitae condimentum lectus, ut imperdiet quam.
                    Maecenas in justo ut nulla aliquam sodales vel at ligula.
                    Sed blandit diam odio, sed fringilla lectus molestie sit
                    amet. Praesent eu tortor viverra lorem mattis pulvinar
                    feugiat in turpis. Class aptent taciti sociosqu ad litora
                    torquent per conubia nostra, per inceptos himenaeos. Fusce
                    ullamcorper tellus sit amet mattis dignissim. Phasellus ut
                    metus ligula. Curabitur nec leo turpis. Ut gravida purus
                    quis erat pretium, sed pellentesque massa elementum. Fusce
                    vestibulum porta augue, at mattis justo. Integer sed sapien
                    fringilla, dapibus risus id, faucibus ante. Pellentesque
                    mattis nunc sit amet tortor pellentesque, non placerat neque
                    viverra.
                  </p>
                </article>
              </InfoBar>
            </div>
            <div id="p-column1" class="pg-item left">
              <h4>Technologies</h4>
              <figure class="imagecard">
                <img src="@/assets/images/laptop.jpg" alt="Laptop" />
                <div class="date">
                  <span class="day">07</span><span class="month">MAY</span>
                </div>
                <i class="ion-film-marker"></i>
                <figcaption>
                  <h3>Why productivity matters</h3>
                  <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Sunt quos illo quaerat. Quam sunt at asperiores nesciunt
                    sint cumque velit harum commodi, quibusdam exercitationem
                    unde iusto adipisci minus molestiae ratione!
                  </p>
                  <button>More</button>
                </figcaption>
                <a href="#"></a>
              </figure>
            </div>
            <div id="p-column2" class="pg-item left">
              <h4>HTML</h4>
              <p>
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sequi
                vero esse labore, vitae quo sed, suscipit reiciendis maxime
                tempora nisi neque optio placeat repudiandae unde. Maxime
                recusandae ex fuga sed vitae labore, consectetur asperiores
                veritatis cum, atque saepe assumenda? Similique dolorem dolores
                a veritatis voluptatem voluptate mollitia repellat at sequi
                ipsam, facere illo cupiditate aliquid ratione quod. Eligendi
                quos dignissimos a quas aliquam ea odio iusto provident odit
                cumque? Earum dolor libero necessitatibus minima laborum quam
                perspiciatis voluptatibus accusantium dolorem nemo eveniet
                repudiandae architecto quidem facere eius quos, deserunt,
                tempore, explicabo alias commodi dolorum aliquid hic impedit
                praesentium. Labore, atque.
              </p>
              <router-link to="/" class="link-button">More</router-link
              >&nbsp;&nbsp;
            </div>

            <div id="p-footer" class="pg-item"></div>
          </div>
        </article>
        <footer></footer>
      </article>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "Main",
  props: {
    msg: String,
  },

  // setup() {
  //   return { timeDate };
  // },
});
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.logo {
  img {
    padding: 5px;
    width: 60px;
    height: 70px;
  }
  .logo-title {
    display: block;
    font-size: 10px;
    width: 50px;
    margin: -10px 0px;
    margin-left: 5px;
    padding: 2px;
    font-weight: 600;
    font-size: 11px;
    text-align: center;
    letter-spacing: -0.5px;
    color: $accent-900;
    background-color: $primary-100;
  }
}
.subsript {
  color: $primary-600;
  margin-top: -1em;
  font-size: 1em;
  line-height: -1;
}
</style>
