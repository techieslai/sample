<template>
  <div id="wrapper">
    <!-- Menu -->
    <div id="main">
      <!-- page -->
      <main class="page">
        <header>
          <div class="title">
            <h1>Dashboard</h1>
            <p>Your personal space to manage the tools</p>
          </div>
          <div class="meta"></div>
        </header>

        <article>
          <div class="page-grid-2">
            <div id="p-header" class="pg-item left">
              <div class="tile-container board-shadow">
                <h2>My Apps</h2>
                <p>
                  <Tiles :data="dataSet" />
                </p>
                <router-link to="/" class="link-button">Some Link</router-link>
              </div>
            </div>
            <div id="p-column1" class="pg-item left">
              <h3>Recent</h3>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam
                eveniet, hic mollitia ab et sed nostrum beatae, recusandae
                asperiores reprehenderit, tempora provident praesentium quod
                velit tempore quaerat dignissimos. Expedita cumque autem vero
                eveniet aut alias non quod deleniti ipsa quae. Quas,
                necessitatibus rerum eius ducimus est laborum, atque alias
                optio, asperiores labore architecto ipsam! Magni!
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column2" class="pg-item left">
              <h3>Suggestions</h3>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. In
                tempora vitae consequatur! Maxime consequatur deserunt cum, modi
                ipsam sint, animi omnis ex sit autem libero eius, iste aperiam
                minus molestiae aspernatur! Explicabo ducimus eveniet beatae
                inventore corrupti dolore et tenetur?
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-footer" class="pg-item">Some footer column</div>
          </div>
        </article>
      </main>
    </div>
  </div>

  <!-- <ul v-for="(item, index) in dataSet.response" :key="index">
            <li>{{ index }} : {{ item.firstname + " " + item.lastname }}</li>
           </ul> -->
</template>

<script lang="ts">
import { APIUtility } from "@/services/api";
import { defineComponent, onBeforeMount, onUpdated, reactive, ref } from "vue";
import Loader from "@/components/common/Loader.vue"; // @ is an alias to /src
import Tiles from "@/components/common/Tiles.vue"; // @ is an alias to /src
import { APP_TILES } from "@/data/settings";

export default defineComponent({
  name: "Dashboard",
  props: {
    msg: String,
  },
  components: { Loader, Tiles },
  emits: ["alert"],
  setup(props, { emit }) {
    const isLoading = ref(true);
    let dataSet = reactive({});
    let apiUtil = new APIUtility();
    isLoading.value = true;
    const refresh = () => {
      isLoading.value = true;
      dataSet = APP_TILES;
    };
    onBeforeMount(() => {
      refresh();
    });
    onUpdated(() => {
      isLoading.value = false;
    });

    refresh();
    return { refresh, isLoading, dataSet };
  },
});
</script>
<style lang="scss" scoped>
.tile-container {
  padding: 1em;
  border-radius: 15px;
}
</style>

