<template>
  <div id="wrapper">
    <!-- Menu -->
    <div id="main">
      <!-- page -->
      <article class="page">
        <header>
          <div class="title">
            <h1>Settings</h1>
            <p>Take a look at the reusable components</p>
          </div>
          <div class="meta">
            <router-link to="/" class="tool-link"
              ><fa class="icon-sm" icon="home"
            /></router-link>
          </div>
        </header>
        <Callout :title="errTitle" :msgs="errMsgs" />
        <article>
          <div class="page-grid-3">
            <div id="p-header" class="pg-item left">
              <h4>Profile Settings</h4>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid
                praesentium, cumque quo commodi voluptatum culpa neque pariatur
                perferendis quos? Harum, quasi sunt pariatur cupiditate mollitia
                excepturi distinctio ullam iure tempora?
              </p>
              <Expander icon="user" title="Profile">
                <InfoBar type="normal" title="Keyboard">
                  <article class="form-box"></article>
                </InfoBar>
              </Expander>
            </div>
            <div id="p-header" class="pg-item left">
              <h4>Profile Settings</h4>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid
                praesentium, cumque quo commodi voluptatum culpa neque pariatur
                perferendis quos? Harum, quasi sunt pariatur cupiditate mollitia
                excepturi distinctio ullam iure tempora?
              </p>
              <Expander icon="user" title="Profile">
                <div class="control-group"></div>
              </Expander>
              <Expander icon="keyboard" title="Keypad">
                <div class="">
                  <div class="control-group">
                    <label class="form-control">Code 1</label>
                    <input
                      v-if="kmode === 'edit'"
                      type="text"
                      name="code1"
                      id="code1"
                      class="form-control"
                      placeholder="enter keypad code 1"
                      v-model="kPyld.code1"
                      @keyup="refresh"
                    />
                    <span class="small disable" v-if="kmode === 'edit'"
                      >Use any phrases like "The sky is red"</span
                    >

                    <label class="form-data" v-if="kmode === 'normal'">
                      {{ kPyld.code1 }}
                    </label>
                    <label class="form-control">Code 2</label>
                    <input
                      v-if="kmode === 'edit'"
                      type="text"
                      name="code2"
                      id="code2"
                      class="form-control"
                      placeholder="enter keypad code 2"
                      v-model="kPyld.code2"
                      @keyup="refresh"
                    />
                    <span class="small" v-if="kmode === 'edit'"
                      >Use any numbers like phone numbers</span
                    >
                    <label v-if="kmode === 'normal'" class="form-data">
                      {{ kPyld.code2 }}
                    </label>
                  </div>
                  <div v-if="kmode === 'edit'" class="control-group">
                    <label class="form-control">Secret code</label>
                    <input
                      type="password"
                      name="scode"
                      id="scode"
                      class="form-control"
                      placeholder="enter your secret code"
                      v-model="kPyld.scode"
                    />
                    <label class="form-control">Confirm secret code</label>
                    <input
                      type="password"
                      name="sccode"
                      id="sccode"
                      class="form-control"
                      placeholder="enter your secret code"
                      v-model="kPyld.sccode"
                    />
                  </div>
                </div>
                <div id="p-footer" class="pg-item right">
                  <p>
                    <a
                      v-if="kmode === 'normal'"
                      class="link-button"
                      @click="kmode = 'edit'"
                      >Edit</a
                    >
                    <a v-if="kmode === 'edit'" class="link-button" @click="save"
                      >Save</a
                    >
                    <a
                      v-if="kmode === 'edit'"
                      class="link-button cancel"
                      @click="kmode = 'normal'"
                      >Cancel</a
                    >
                  </p>
                </div>
              </Expander>
              <Expander icon="laptop-code" title="Activity log"> </Expander>
              <Expander icon="laptop-code" title="Apps"> </Expander>
            </div>
          </div>
        </article>
        <footer></footer>
      </article>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, ref } from "vue";
import InfoBar from "@/components/common/InfoBar.vue";
import Expander from "@/components/common/Expander.vue";
import { FDBUtility } from "@/services/fdbutility";
import { Validation } from "@/services/validation";
import Callout from "@/components/common/Callout.vue";

export default defineComponent({
  name: "Settings",
  props: {
    msg: String,
  },
  components: { InfoBar, Expander, Callout },

  setup(_, { emit }) {
    interface pyld {
      kpad_name: string;
      code1: string;
      code2: string;
      scode: string;
      sccode: string;
    }
    const kmode = ref("normal");
    const kPyld = reactive(<pyld>{});
    const errTitle = ref("Input Error");
    const refresh_key = ref(0);
    const errMsgs = ref();
    const docId = ref();
    let fdb = new FDBUtility("keypads");
    fdb
      .getAll()
      .then((response: any) => {
        kPyld.code1 = response[0].code1 || "";
        kPyld.code2 = response[0].code2 || "";
        kPyld.scode = response[0].scode || "";
        docId.value = response[0].doc_id || "";
      })
      .catch((e: any) => {
        emit("alert", "Error", "Error loading the data");
      });

    const save = () => {
      if (kPyld.scode === kPyld.sccode && kPyld.scode != "") {
        let vldnForm: any = validateForm();
        if (vldnForm.result) {
          errMsgs.value = vldnForm.messages;
        } else {
          try {
            let fdb = new FDBUtility("keypads");
            fdb.update(docId.value, {
              code1: kPyld.code1,
              code2: kPyld.code2,
              scode: kPyld.scode,
            });
            emit("alert", "Keypad", "Keypad settings saved");
            kmode.value = "normal";
          } catch (e: any) {
            errMsgs.value = [e.message];
          }
        }
      } else {
        errMsgs.value = ["Conirm secret code donot match"];
      }
      //refresh_key.value = refresh_key.value + 1;
    };

    const validateForm = () => {
      let vldn = new Validation();
      const rules = {
        code1: {
          rules: ["REQUIRED", "MIN-6", "MAX-30"],
          description: "Code 1",
        },
        code2: {
          rules: ["REQUIRED", "MIN-6", "MAX-30"],
          description: "Code 2",
        },
        scode: {
          rules: ["REQUIRED", "MIN-6", "MAX-30"],
          description: "Secret code",
        },
      };
      return vldn.validatePayload(kPyld, rules);
    };

    return { kmode, save, errTitle, kPyld, errMsgs, refresh_key };
  },
});
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.logo {
  img {
    padding: 5px;
    width: 60px;
    height: 70px;
  }
  .logo-title {
    display: block;
    font-size: 10px;
    width: 50px;
    margin: -10px 0px;
    margin-left: 5px;
    padding: 2px;
    font-weight: 600;
    font-size: 11px;
    text-align: center;
    letter-spacing: -0.5px;
    color: $accent-900;
    background-color: $primary-100;
  }
}
.subsript {
  color: $primary-600;
  margin-top: -1em;
  font-size: 1em;
  line-height: -1;
}
.control-group {
  border: 1px solid $primary-100;
  margin-bottom: 0.5em;
  padding: 1em;
  max-width: 500px;
  background: $white;
}
.form-group {
  border: 1px solid $primary-100;
  background: $primary-100;
  margin-bottom: 0.5em;
  padding: 1em;
  max-width: 500px;
}
</style>
