<template>
  <article>
    <div class="page-grid center">
      <div id="p-header" class="pg-item center">
        <div class="page-grid-2">
          <div id="p-column1" class="pg-item left pg-content">
            <h4>Unlock your Keyboard</h4>
            <div class="form-box">
              <div class="control-group">
                <label class="form-control">Secret code</label>
                <input
                  type="password"
                  name="scode"
                  id="scode"
                  class="form-control"
                  placeholder="enter your secret code"
                  v-model="secretKey"
                  @keyup="refresh"
                />
              </div>
            </div>
            <label
              v-if="!(secretKey === kPyld['scode'] && kPyld['scode'] != '')"
              class="badge large noround default"
              >Your Keyboard is currently Locked</label
            >
            <label
              class="badge large noround success"
              v-if="secretKey === kPyld['scode'] && kPyld['scode'] != ''"
              >Keyboard is Unlocked</label
            >
          </div>
          <div id="p-column2" class="pg-item left pg-content">
            <InfoBar type="info" title="How to use the Keyboard?">
              <li>
                This keyboard is customized based on your keyboard settings.
              </li>
              <li>
                You need to unlock your keyboard by entering the secret code.
              </li>
              <li>You can type any of your password and click COPY.</li>
              <li>Use the encrypted password for any websites.</li>
              <br />
              <h6>NOTE: Secret code will not be saved for privacy.</h6>
            </InfoBar>
          </div>
        </div>
      </div>

      <div id="p-footer" class="pg-item">
        <div class="tile-container">
          <div class="display-panel center">
            <div class="display innershadow">
              <h2>
                <span v-for="(t, ind) in passText" :key="ind">
                  {{ t.text }}
                </span>
              </h2>
              <h3>
                <span v-if="showEncpt">
                  {{ keyCtrl }}
                </span>
              </h3>
            </div>
          </div>
          <div class="tile-inner">
            <template v-for="(key, index) in keyData" :key="index">
              <div class="tile" @click="keyClick(index)">
                <span class="tile-subtext">
                  {{ showEncpt ? key.encpt : "&nbsp;" }}</span
                >
                <span class="tile-text">{{ key.text }}</span>
              </div>
            </template>
            <br />
            <div class="tile tool" @click="showEncptText()">
              <span class="tile-subtext">&nbsp;</span>
              <span class="tile-text"><fa class="icon-sm1" icon="eye" /></span>
            </div>
            <div class="tile tool" @click="toolClick('DEL')">
              <span class="tile-subtext">&nbsp;</span>
              <span class="tile-text">DEL</span>
            </div>
            <div class="tile tool" @click="toolClick('CLR')">
              <span class="tile-subtext">&nbsp;</span>
              <span class="tile-text">CLR</span>
            </div>
            <div class="tile tool" @click="toolClick('COPY')">
              <span class="tile-subtext">&nbsp;</span>
              <span class="tile-text"><Clip :value="keyCtrl" /></span>
            </div>
          </div>
        </div>
        <div id="p-footer" class="pg-item">
          <br />
          This is your personalized keyboard. Please save the snapshot of the
          keyboard for manual entries and for your
        </div>
      </div>
    </div>
  </article>
</template>

<script lang="ts">
import { Utility } from "@/services/utility";
import Clip from "@/components/user/apps/keypad/Clip.vue";
import Expander from "@/components/common/Expander.vue";
import InfoBar from "@/components/common/InfoBar.vue";
import {
  computed,
  defineComponent,
  onBeforeMount,
  reactive,
  ref,
  watch,
} from "vue";
import store from "@/store";
import { FDBUtility } from "@/services/fdbutility";
export default defineComponent({
  name: "Passpad",
  props: {
    unlocked: Boolean,
  },
  components: { Clip, Expander, InfoBar },
  emits: ["validate", "alert"],

  setup(props, { emit }) {
    const code = ref([]);
    const name = ref([]);
    const user = ref();
    const code1 = ref();
    const code2 = ref();
    const secretKey = ref();
    const secret = ref([]);
    const keypad = <any>"ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890-.@";
    const keyData = ref();
    const keyCtrl = ref();
    const kPyld = reactive({ code1: "", code2: "", scode: "" });
    const showEncpt = ref(false);
    let passText = reactive(Array());

    let fdb = new FDBUtility("keypads");
    fdb
      .getAll()
      .then((response: any) => {
        kPyld["code1"] = <any>response[0].code1 || "";
        kPyld["code2"] = <any>response[0].code2 || "";
        kPyld["scode"] = <any>response[0].scode || "";
        refresh();
      })
      .catch((e: any) => {
        emit("alert", "Error", "Error loading the keypad details");
      });

    const refresh = () => {
      let util = new Utility();
      let str = <any>kPyld["code1"] || "";
      str = str.replaceAll(" ", "").toLowerCase();
      let revstr = <any>util.stringReverse(str);
      name.value = revstr + str + revstr + str;

      str = <any>secretKey.value || "";
      str = str.replaceAll(" ", "").toLowerCase();
      revstr = <any>util.stringReverse(str);
      secret.value = revstr + str + revstr + str;

      str = <any>kPyld["code2"] || "";
      str = str.replaceAll(" ", "").toLowerCase();
      revstr = <any>util.stringReverse(str);
      code.value = revstr + str + revstr + str;

      let x = new Array();
      for (let i = 0; i < keypad.length; i++) {
        let elObj: any = {};
        let encptText =
          (name.value[i] || "") +
          (secret.value[i] || "") +
          (code.value[i] || "");
        elObj = {
          text: keypad[i],
          encpt: encptText,
        };
        if (i > 35) {
          elObj = {
            text: keypad[i],
            encpt: keypad[i],
          };
        }
        x.push(elObj);
      }
      keyData.value = <any>x;
    };
    const showEncptText = () => {
      showEncpt.value = !showEncpt.value;
      setTimeout(function () {
        showEncpt.value = false;
      }, 5000);
    };

    const keyClick = (ind: number) => {
      let enc = <any>keyData.value[ind];
      let elObj = <any>{
        index: ind,
        text: enc.text,
        encptText: enc.encpt,
      };
      passText.push(elObj);
      keyCtrl.value = getKeyStr();
    };
    const toolClick = (key: string) => {
      if (key === "DEL") {
        passText.splice(passText.length - 1, 1);
      }
      if (key === "CLR") {
        passText.splice(0, passText.length);
      }
      if (key === "COPY") {
        passText.splice(0, passText.length);
      }
      keyCtrl.value = getKeyStr();
    };

    const getKeyStr = () => {
      let ptext = "";
      passText.forEach((el) => {
        ptext = ptext + el.encptText;
      });
      ptext = ptext.substring(0, ptext.length - 1);
      let str =
        (
          ptext.substring(0, 1) +
          ptext.length +
          ptext.substring(ptext.length - 1)
        ).toUpperCase() +
        "@" +
        ptext;
      str = str === "0@" ? "" : str;
      return str;
    };

    return {
      keyData,
      keyClick,
      toolClick,
      passText,
      showEncpt,
      showEncptText,
      keyCtrl,
      secretKey,
      refresh,
      user,
      kPyld,
    };
  },
});
</script>
<style lang="scss" scoped>
.tile-container {
  background-color: $primary-100;
  .display {
    display: grid;
    margin: auto;
    background-color: $primary-900;
    padding: 0.5em;
    height: 80px;
    h2 {
      color: $primary-100;
      font-size: 1.5em;
    }
    h3 {
      color: $primary-500;
      font-size: 0.9em;
    }
  }
}
.tile-inner {
  padding: 3em;
}
.pg-item {
  padding: 0;
  width: 100%;
}
.innershadow {
  -moz-box-shadow: inset 0 0 20px #2b2a2a;
  -webkit-box-shadow: inset 0 0 20px #2b2a2a;
  box-shadow: inset 0 0 20px #2b2a2a;
}
.display-panel {
  background-color: $primary-700;
  padding: 0.5em;
}
.tile {
  align-content: center;
  text-align: center;
  margin: 0.1em;
  background: white;
  width: 70px;
  height: 70px;
  border: 1px solid $primary-100;
  box-shadow: 6px 6px 8px 0 rgba(0, 0, 0, 0.25),
    -4px -4px 6px 0 rgba(255, 255, 255, 0.3);
  cursor: pointer;
  display: inline-block;
  font-size: 1.2em;
  -webkit-transition: 0.2s ease-in-out;
  transition: 0.2s ease-in-out;

  .tile-text {
    display: block;
    font-size: 1em;
    font-weight: bold;
    color: $primary-700;
    margin-top: -0.5em;
  }
  .tile-icon {
    display: block;
    color: $accent-700;
    margin-left: 0.5em;
  }
  .tile-subtext {
    font-size: 0.8em;
    color: $primary-500;
  }
  .disable {
    color: $primary-300;
  }
}
.tool {
  background-color: $primary-300;
  font-size: 1em;
}
.tile:hover {
  background-color: $accent-800;
  border: 1px solid $white;
  .tile-text {
    color: $white;
  }
  .tile-subtext {
    color: $white;
  }
  box-shadow: none;
}
.card {
  padding: 0.2em;
  box-shadow: 6px 6px 8px 0 rgba(0, 0, 0, 0.25),
    -4px -4px 6px 0 rgba(255, 255, 255, 0.3);
}

@media only screen and (max-width: 1024px), (max-device-width: 1024px) {
  .tile-inner {
    padding: 0.5em;
  }
  .tile {
    font-size: 1.2em;
    width: 50px;
    height: 50px;
  }
  .tool {
    font-size: 0.8em;
  }
}
</style>