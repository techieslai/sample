<template>
  <div id="wrapper">
    <!-- Menu -->
    <div id="main">
      <!-- page -->
      <main class="page">
        <header>
          <div class="title">
            <h1>Personal Keypad</h1>
            <p>Encrypted keypad for your personal use</p>
          </div>
          <div class="meta">
            <router-link to="/dashboard" class="tool-link"
              ><fa class="icon-sm" icon="th"
            /></router-link>
            <!-- <label>Updated {{ $filters.timeAgo(Date().now) }}</label> -->
          </div>
        </header>
        <article>
          <div class="page-grid-1">
            <div id="p-header" class="pg-item"></div>
            <div id="p-column1"><PassPad /></div>
            <div id="p-footer" class="pg-item"></div>
          </div>
        </article>
      </main>
    </div>
  </div>
</template>

<script lang="ts">
import { APIUtility } from "@/services/api";
import { defineComponent, onBeforeMount, onUpdated, reactive, ref } from "vue";
import Loader from "@/components/common/Loader.vue"; // @ is an alias to /src
import PassPad from "@/components/user/apps/keypad/PassPad.vue"; // @ is an alias to /src

export default defineComponent({
  name: "PassManager",
  props: {
    msg: String,
  },
  components: { Loader, PassPad },
  emits: ["alert"],
  setup(props, { emit }) {
    const isLoading = ref(true);
    let dataSet = reactive({
      response: "",
    });
    let apiUtil = new APIUtility();
    isLoading.value = true;
    const refresh = () => {
      isLoading.value = true;
    };
    onBeforeMount(() => {
      refresh();
    });
    onUpdated(() => {
      isLoading.value = false;
    });

    refresh();
    return { refresh, isLoading, dataSet };
  },
});
</script>

