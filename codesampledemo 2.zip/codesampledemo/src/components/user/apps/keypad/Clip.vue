<template>
  <div class="center" @click="copyToClipboard">
    <span type="hidden" id="copy-code" :value="value" />
    COPY
  </div>
</template>
<script lang="ts">
import { defineComponent, ref } from "vue";
export default defineComponent({
  name: "Clip",
  props: {
    value: String,
  },
  setup(props, { emit }) {
    const copyToClipboard = () => {
      const el = document.createElement("textarea");
      el.value = <any>props.value;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
    };
    return {
      copyToClipboard,
    };
  },
});
</script>

<style lang="scss" scoped>

</style>






