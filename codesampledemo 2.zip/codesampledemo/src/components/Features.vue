<template>
  <div id="wrapper">
    <!-- Menu -->
    <div id="main">
      <!-- page -->
      <article class="page">
        <header>
          <div class="title">
            <h1>Features</h1>
            <p>Overview of the features</p>
          </div>
          <div class="meta">
            <router-link to="/" class="tool-link"
              ><fa class="icon-sm" icon="home"
            /></router-link>
          </div>
        </header>
        <article>
          <div class="page-grid-121">
            <div id="p-header" class="pg-item left">
              <h2>Productivity Tools</h2>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid
                praesentium, cumque quo commodi voluptatum culpa neque pariatur
                perferendis quos? Harum, quasi sunt pariatur cupiditate mollitia
                excepturi distinctio ullam iure tempora?
              </p>
              <InfoBar type="normal" title="Summary">
              <article class="page shadow">
                <p>
                  Mauris neque quam, fermentum ut nisl vitae, convallis maximus
                  nisl. Sed mattis nunc id lorem euismod placerat. Vivamus
                  porttitor magna enim, ac accumsan tortor cursus at. Phasellus
                  sed ultricies mi non congue ullam corper. Praesent tincidunt
                  sed tellus ut rutrum. Sed vitae justo condimentum, porta
                  lectus vitae, ultricies congue gravida diam non fringilla.
                </p>
                <p>
                  Nunc quis dui scelerisque, scelerisque urna ut, dapibus orci.
                  Sed vitae condimentum lectus, ut imperdiet quam. Maecenas in
                  justo ut nulla aliquam sodales vel at ligula. Sed blandit diam
                  odio, sed fringilla lectus molestie sit amet. Praesent eu
                  tortor viverra lorem mattis pulvinar feugiat in turpis. Class
                  aptent taciti sociosqu ad litora torquent per conubia nostra,
                  per inceptos himenaeos. Fusce ullamcorper tellus sit amet
                  mattis dignissim. Phasellus ut metus ligula. Curabitur nec leo
                  turpis. Ut gravida purus quis erat pretium, sed pellentesque
                  massa elementum. Fusce vestibulum porta augue, at mattis
                  justo. Integer sed sapien fringilla, dapibus risus id,
                  faucibus ante. Pellentesque mattis nunc sit amet tortor
                  pellentesque, non placerat neque viverra.
                </p>
              </article>
              </InfoBar>
            </div>
            <div id="p-column1" class="pg-item left">
              <h4>Technologies</h4>
              <Context :menu="FEATURE_MENU" />
            </div>
            <div id="p-column2" class="pg-item left">
              <h4>HTML</h4>
              <p>
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sequi
                vero esse labore, vitae quo sed, suscipit reiciendis maxime
                tempora nisi neque optio placeat repudiandae unde. Maxime
                recusandae ex fuga sed vitae labore, consectetur asperiores
                veritatis cum, atque saepe assumenda? Similique dolorem dolores
                a veritatis voluptatem voluptate mollitia repellat at sequi
                ipsam, facere illo cupiditate aliquid ratione quod. Eligendi
                quos dignissimos a quas aliquam ea odio iusto provident odit
                cumque? Earum dolor libero necessitatibus minima laborum quam
                perspiciatis voluptatibus accusantium dolorem nemo eveniet
                repudiandae architecto quidem facere eius quos, deserunt,
                tempore, explicabo alias commodi dolorum aliquid hic impedit
                praesentium. Labore, atque.
              </p>
              <router-link to="/" class="link-button">More</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column3" class="pg-item left">
              <h5>Other Frameworks</h5>
              <nav>
                <p>
                  <a href="#">Angular</a>
                  <a href="#">React</a>
                </p>
              </nav>
            </div>
            <div id="p-footer" class="pg-item"></div>
          </div>
        </article>
        <footer>

        </footer>
      </article>

      <article class="page">
        <header>
          <div class="title">
            <h1>Upcoming Features</h1>
            <p>
              Created to help improving your productivity so that you can focus
              on other important things
            </p>
          </div>
        </header>

        <p>
          Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl.
          Sed mattis nunc id lorem euismod placerat. Vivamus porttitor magna
          enim, ac accumsan tortor cursus at. Phasellus sed ultricies mi non
          congue ullam corper. Praesent tincidunt sed tellus ut rutrum. Sed
          vitae justo condimentum, porta lectus vitae, ultricies congue gravida
          diam non fringilla.
        </p>
        <p>
          Nunc quis dui scelerisque, scelerisque urna ut, dapibus orci. Sed
          vitae condimentum lectus, ut imperdiet quam. Maecenas in justo ut
          nulla aliquam sodales vel at ligula. Sed blandit diam odio, sed
          fringilla lectus molestie sit amet. Praesent eu tortor viverra lorem
          mattis pulvinar feugiat in turpis. Class aptent taciti sociosqu ad
          litora torquent per conubia nostra, per inceptos himenaeos. Fusce
          ullamcorper tellus sit amet mattis dignissim. Phasellus ut metus
          ligula. Curabitur nec leo turpis. Ut gravida purus quis erat pretium,
          sed pellentesque massa elementum. Fusce vestibulum porta augue, at
          mattis justo. Integer sed sapien fringilla, dapibus risus id, faucibus
          ante. Pellentesque mattis nunc sit amet tortor pellentesque, non
          placerat neque viverra.
        </p>
        <footer>
          <!-- <ul class="stats">
            <li><a href="#">General</a></li>
            <li><a href="#" class="icon solid fa-heart">28</a></li>
            <li><a href="#" class="icon solid fa-comment">128</a></li>
          </ul> -->
        </footer>
      </article>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";
import Context from "@/components/common/Context.vue";
import { FEATURE_MENU } from "@/data/settings";
import InfoBar from "./common/InfoBar.vue";

export default defineComponent({
  name: "Features",
  props: {
    msg: String,
  },
  components: { Context, InfoBar },
  setup() {
    return { FEATURE_MENU };
  },
});
</script>
<style lang="scss" scoped>
nav > p > a {
  display: block;
  text-decoration: none;
  color: $accent-900;
  background-color: $primary-100;
  border-left: 2px solid $accent-800;
  padding: 0.3em 1em;
  margin-bottom: 0.1em;
  transition: 0.2s ease-in-out;
  font-size: 0.9em;
  font-weight: 600;
}
nav > p > a:hover,
nav > p > a:active {
  display: block;
  background-color: $accent-800;
  color: $white;
}
</style>

