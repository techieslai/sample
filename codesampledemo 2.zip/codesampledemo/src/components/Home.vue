<template>
  <div id="wrapper">
    <!-- Menu -->
    <div id="main">
      <!-- page -->
      <main class="page">
        <article>
          <div class="page-grid-2 banner">
            <div class="hero">
              <div id="p-header" class="pg-item left">
                <h2>{{ APP_NAME }}</h2>
                <h1>{{ APP_HERO }}</h1>
                <p>
                  You deserve a place for good tools to save your time and
                  energy
                </p>
                <router-link to="/register" class="register"
                  >Register Now</router-link
                >
              </div>
              <div id="p-column1" class="pg-item left"></div>
            </div>
            <div id="p-column2" class="pg-item right">
              <div class="hero-right"></div>
            </div>
            <div id="p-footer" class="pg-item"></div>
          </div>
        </article>
        <article>
          <div class="page-grid-2 hero-summary">
            <div id="p-header" class="pg-item left">
              <h2>My Motivation</h2>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero
                velit excepturi amet labore sed adipisci officia cum aspernatur
                tenetur quas quae exercitationem accusantium ipsum eveniet
                accusamus suscipit, magnam odit eius expedita pariatur neque.
                Asperiores molestias, quod nostrum laboriosam dolore dolores
                vitae a voluptatibus, accusamus repellat, soluta saepe
                consectetur? Accusantium illum illo, alias sint harum porro
                voluptates reiciendis atque quis earum odio id iusto accusamus
                adipisci eligendi similique libero itaque eveniet aliquid at
                quasi odit ratione! Sed modi accusamus amet minus?
              </p>
              <router-link to="/" class="link-button">More</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column1" class="pg-item left">
              <h3>Tools</h3>
              <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit.
                Architecto, consectetur iusto. Porro, natus exercitationem,
                veritatis libero delectus quibusdam, nostrum quod hic voluptatum
                facere quo. Aspernatur tempora distinctio nemo tempore alias
                veniam officia placeat ea impedit. Accusantium, facilis. Vitae
                eum inventore odio repellat necessitatibus, adipisci repellendus
                omnis voluptas corrupti laudantium nostrum officiis ut incidunt
                porro sequi iste. Omnis quam sed maiores. Explicabo temporibus
                rem, dolore, nisi pariatur quo inventore, officia ad commodi
                placeat distinctio odio labore libero in. Architecto sunt unde
                odit beatae molestias, ab blanditiis totam provident sequi enim,
                omnis ex voluptatum ad ullam nesciunt praesentium voluptate
                libero culpa eaque?
              </p>
              <router-link to="/" class="link-button">More</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column2" class="pg-item left">
              <h3>Benefits</h3>
              <p>
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Amet,
                ullam. Itaque alias fugit eligendi quas in voluptatem
                accusantium, nesciunt recusandae nihil eveniet, sit aliquid sed
                maiores perspiciatis harum ab temporibus tempora rem delectus
                inventore reprehenderit. Voluptatum voluptate nemo eligendi
                aspernatur? Sit nulla, repellat vel corporis ea delectus. Quae
                doloribus nihil culpa est itaque unde iusto, sed voluptate dicta
                expedita provident vel, ut et, explicabo pariatur exercitationem
                voluptas corporis commodi ullam accusamus ratione quis impedit.
                Rerum nulla mollitia adipisci libero at sequi sint esse
                assumenda corporis nisi! Itaque totam minima et quisquam
                pariatur sint, quidem facere atque ipsa deleniti velit suscipit.
              </p>
              <router-link to="/" class="link-button">More</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-footer" class="pg-item"></div>
          </div>
        </article>
        <hr />
        <article>
          <div class="page-grid-3">
            <div id="p-header" class="pg-item left">
              <h2>How to use this?</h2>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit
                neque natus blanditiis nesciunt id quae recusandae magnam
                debitis aperiam fugiat. Veniam rerum vitae ab assumenda itaque
                quo. Similique, asperiores voluptas.
              </p>
            </div>
            <div id="p-column1" class="pg-item left">
              <h3>Explore</h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Dolores ipsum vitae consequuntur fuga incidunt expedita impedit
                iusto reprehenderit ipsam placeat reiciendis illum praesentium
                dolorum, laborum voluptatum ipsa, cupiditate officiis. Eius,
                ratione voluptas eaque, in laboriosam praesentium a excepturi
                earum architecto ipsa repudiandae. Animi debitis possimus beatae
                quasi earum autem tenetur magnam libero quae delectus recusandae
                cum nulla sapiente iste minus provident, dolores maiores
                molestiae ab ex sequi excepturi? Reprehenderit unde, quos
                perferendis, corporis non dignissimos aliquam illo quam
                repudiandae esse, ratione asperiores. Id numquam odio facilis
                provident voluptas accusamus nisi nostrum esse sit debitis quam
                assumenda consectetur officiis reprehenderit magni molestias,
                quo iusto soluta mollitia sunt. Aliquam nobis repellat suscipit
                nostrum nemo error delectus quae ad modi nam ab atque
                consectetur doloribus architecto aliquid, quo tenetur facere
                harum maiores, nesciunt cum eum? Nulla veniam reiciendis id
                asperiores cumque molestiae voluptate autem dicta sequi, fuga
                deserunt optio laboriosam dolor ipsam, necessitatibus
                perferendis dolore minus quibusdam libero impedit suscipit nemo
                deleniti? Nesciunt dicta quo veritatis harum quas aliquid, nam
                illum vel. Maiores recusandae aspernatur architecto voluptatibus
                asperiores doloribus natus adipisci similique voluptatum iste!
                Numquam nam exercitationem, sed officiis deleniti pariatur
                accusantium, cum porro dignissimos, odit velit suscipit dolores.
                Iure fuga vitae unde.
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column2" class="pg-item left">
              <h3>Try it out</h3>
              <p>
                Saepe quas at ut minus quam illum enim deserunt molestiae
                sapiente consequatur nostrum exercitationem maiores eum nihil
                earum magnam? Id dolore, accusamus ratione expedita ullam eum,
                exercitationem maiores modi corrupti qui quae? Eum cupiditate
                odit excepturi eos, dignissimos porro fugiat architecto dicta
                sequi. Eligendi assumenda accusantium enim rem modi quam, quos
                omnis, expedita veniam obcaecati maxime similique doloremque
                corrupti
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column3" class="pg-item left">
              <h3>Feedback</h3>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe
                repellat soluta, eius totam vitae deserunt mollitia ducimus
                sapiente consequatur recusandae beatae et, aut eligendi,
                asperiores delectus blanditiis rerum suscipit facere.
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-footer" class="pg-item center"></div>
          </div>
        </article>
        <hr />
        <article>
          <div class="page-grid-2">
            <div id="p-header" class="pg-item left">
              <h2>Team</h2>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat
                voluptates modi deleniti, laborum iure corrupti amet ipsam
                ducimus perferendis impedit necessitatibus accusamus natus
                excepturi sapiente illum molestias, assumenda qui! Nemo ipsa
                soluta eligendi nulla et quo labore, saepe quas at ut minus quam
                illum enim deserunt molestiae sapiente consequatur nostrum
                exercitationem maiores eum nihil earum magnam? Id dolore,
                accusamus ratione expedita ullam eum, exercitationem maiores
                modi corrupti qui quae? Eum cupiditate odit excepturi eos,
                dignissimos porro fugiat architecto dicta sequi. Eligendi
                assumenda accusantium enim rem modi quam, quos omnis, expedita
                veniam obcaecati maxime similique doloremque corrupti
                perspiciatis, sapiente optio dicta aperiam cumque pariatur quod
                fugiat corporis. Minus blanditiis doloribus impedit aspernatur
                sequi, neque nulla voluptate quidem in eum? Obcaecati harum
                placeat, ea minima fugiat cupiditate explicabo blanditiis at,
                numquam a cum inventore accusamus voluptates quia quos
              </p>
            </div>
            <div id="p-column1" class="pg-item left">
              <h3>Members</h3>
              <p>
                Giores eum nihil earum magnam? Id dolore, accusamus ratione
                expedita ullam eum, exercitationem maiores modi corrupti qui
                quae? Eum cupiditate odit excepturi eos, dignissimos porro
                fugiat architecto dicta sequi. Eligendi assumenda accusantium
                enim rem modi quam, quos omnis, expedita veniam obcaecati maxime
                similique doloremque corrupti.
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column2" class="pg-item left">
              <h3>Profile</h3>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quia
                qui obcaecati, velit voluptate non a enim vero, consectetur
                ipsam magni autem, iure explicabo unde aliquam sit laboriosam
                commodi veritatis beatae nesciunt veniam aliquid ratione
                voluptatibus? Odio consectetur commodi natus quia magnam
                deserunt temporibus et harum esse! Laboriosam consequuntur
                commodi sunt veniam corrupti provident eaque, libero repellendus
                aut, adipisci natus odit, dicta quaerat iusto? Excepturi earum
                eveniet iusto modi! Ut vitae, repellendus ullam molestias id sed
                eius saepe quidem placeat fugiat accusantium quod ipsam? Vero
                repellendus alias rerum, veritatis impedit fugiat, velit illo
                consequuntur perspiciatis doloremque, repudiandae itaque eius
                laborum! Eveniet accusamus cupiditate perspiciatis dolor eius
                blanditiis qui sint inventore, ut numquam est ratione nulla
                iusto temporibus eligendi iste, dignissimos aut voluptatibus
                minus similique, nihil voluptas in reiciendis a. Perspiciatis
                voluptates possimus ab suscipit molestiae velit repellendus, ex
                dolores recusandae corrupti assumenda. Ipsum velit unde beatae
                maxime id dicta, ipsa voluptatem quod eos adipisci
                exercitationem vitae modi? Soluta, repudiandae, ipsa natus
                adipisci eum est esse nulla iste laboriosam laudantium ipsum ad
                culpa ex expedita voluptate magnam nemo voluptatibus! Nemo est
                laudantium incidunt illum ipsa! Incidunt necessitatibus tempore
                veniam pariatur. Fuga corporis perferendis, assumenda vero sequi
                quasi reprehenderit illum repellat ab ad rerum deserunt ipsa
                omnis voluptatem maiores consequatur repudiandae placeat
                voluptatibus et quisquam? Repellendus molestiae est incidunt
                excepturi rem, illum nisi sapiente hic possimus sed nostrum,
                sint, voluptates sequi vero facilis? Excepturi expedita illum,
                magni fugiat rerum provident dolorum obcaecati dolorem fuga
                repellat asperiores amet nisi hic consectetur ipsa doloremque
                sunt dolore eligendi tenetur error vitae inventore! Eius
                reiciendis molestiae in repellendus eligendi soluta at
                accusantium praesentium, laboriosam quam a veritatis iure iusto
                est corporis. Maxime possimus ipsa consequatur, nostrum error
                exercitationem at, eveniet deserunt accusantium tempora
                perferendis hic, nesciunt odio labore omnis? Sunt repellat sint
                accusantium, harum officia reiciendis obcaecati tempora magnam
                ipsa explicabo modi natus fugiat eius porro quasi doloremque
                dicta temporibus earum quaerat cupiditate laborum ea
                consequuntur nam? Voluptates dolorem nobis harum consequuntur
                repellat recusandae, libero omnis perferendis ab similique vero
                distinctio dolores maxime maiores odit quaerat officiis eius
                officia expedita aut! Maxime facilis temporibus ullam eius
                magnam quisquam voluptatibus atque numquam amet, tempore, illo
                accusamus minus non perspiciatis iste! Earum voluptate iusto
                impedit inventore sit dolorum exercitationem ut perferendis sed
                asperiores est quia quibusdam accusantium mollitia, dolore
                labore reprehenderit voluptates illo optio cum delectus
                assumenda commodi? Corporis tempora voluptatem id sint, at
                laudantium aut dicta voluptas maxime?
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-footer" class="pg-item">Some footer column</div>
          </div>
        </article>
      </main>
    </div>
  </div>

  <!-- <ul v-for="(item, index) in dataSet.response" :key="index">
            <li>{{ index }} : {{ item.firstname + " " + item.lastname }}</li>
           </ul> -->
</template>

<script lang="ts">
import { APIUtility } from "@/services/api";
import { defineComponent, onBeforeMount, onUpdated, reactive, ref } from "vue";
import Loader from "@/components/common/Loader.vue"; // @ is an alias to /src
import { APP_NAME, APP_HERO } from "@/data/settings";

export default defineComponent({
  name: "Home",
  props: {
    msg: String,
  },
  components: { Loader },
  emits: ["alert"],
  setup(props, { emit }) {
    const isLoading = ref(true);
    let dataSet = reactive({
      response: "",
    });
    let apiUtil = new APIUtility();
    isLoading.value = true;
    const refresh = () => {
      isLoading.value = true;
      apiUtil
        .getData()
        .then((response: any) => {
          dataSet.response = response["data"];
        })
        .catch((e: any) => {
          emit("alert", "Error", "Error loading the data");
        });
    };
    onBeforeMount(() => {
      refresh();
    });
    onUpdated(() => {
      isLoading.value = false;
    });

    refresh();
    return { APP_NAME, APP_HERO, refresh, isLoading, dataSet };
  },
});
</script>

<style lang="scss" scoped>
.hero {
  padding: 2em;
  margin: auto;
  vertical-align: middle;
}
.hero-right {
  color: $white;
}

.banner {
  display: flex;
  margin: auto;
  background: url(../assets/images/innovation.jpg);
  opacity: 0.9;
  filter: alpha(opacity=50); /* For IE8 and earlier */
  max-width: 100%;
  border-radius: 10px;
  h2 {
    font-size: 1.15em;
    color: $primary-400;
    margin-bottom: 0em;
  }
  h1 {
    font-size: 2.525em;
    line-height:1.2em;
    color: $white;
  }
  p {
    color: $primary-100;
  }
}
.register {
  border: 1px solid $white;
  color: $white;
  background-color: rgba(0, 0, 0, 0.3);
  text-decoration: none;
  padding: 0.3em 1em;
  font-weight: bold;
  opacity: 0.9;
}
.register:hover {
  background-color: rgba(0, 0, 0, 0.6);
  transition: 0.4s ease-in-out;
}
.hero-summary {
  padding-top: 1em;
}
</style>