<template>
  <div id="wrapper">
    <!-- Menu -->
    <div id="main">
      <!-- page -->
      <main class="page">
        <header>
          <div class="title">
            <h1>Page Header</h1>
            <p>Short description of the page goes here</p>
          </div>
          <div class="meta">
            <router-link to="/" class="tool-link"
              ><fa class="icon-sm" icon="home"
            /></router-link>
            <label>Updated {{ $filters.timeAgo(Date().now) }}</label>
          </div>
        </header>
        <article>
          <div class="page-grid">
            <div id="p-header" class="pg-item left">
              <h2>Page Grid</h2>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa
                eveniet optio necessitatibus fugit nulla. Optio dignissimos
                minima excepturi tenetur debitis? Omnis, atque fugiat delectus
                consectetur esse vel et vero recusandae non tempore voluptatum
                pariatur quae quidem quam inventore sunt illum, enim dolores
                harum, at dolor repellat commodi. Aliquid voluptate amet
                officiis, alias obcaecati optio facilis repudiandae dolore
                cupiditate minima officia numquam nulla odit est modi aut
                tempora ducimus, voluptates sed eum? Beatae voluptas fugiat vel
                eaque odit, laborum recusandae dolores, quae officia maxime,
                reprehenderit eligendi blanditiis quo tempora quia
                exercitationem assumenda accusantium odio dolorem! Doloribus ex
                ullam praesentium debitis quis in deleniti, dicta dolor
                voluptatum repellat autem non error facere magni at ipsa
                architecto laboriosam pariatur a. Id voluptatum facere, aliquam
                consequuntur odit illo saepe. Veniam ut voluptatum consequuntur
                eaque beatae enim debitis maxime iusto magni! Eos itaque earum
                odit nostrum fugiat esse quaerat nesciunt animi molestias. Quis
                deleniti maiores delectus accusantium excepturi rem a quaerat
                necessitatibus iste, est veritatis voluptatibus rerum alias
                blanditiis officiis aperiam. Sint delectus corporis saepe, eaque
                temporibus consequuntur, tempora, inventore voluptatibus soluta
                natus harum. At magni architecto ducimus eum tenetur animi
                molestias rerum possimus perspiciatis autem, totam quos
                doloremque ea culpa sit deserunt, illum odio?
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column1" class="pg-item left">
              <h3>column 1</h3>
              <p>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa
                voluptas animi non modi tenetur maxime quasi inventore,
                recusandae laborum ipsum voluptatibus aliquam id perferendis
                impedit labore veniam distinctio aperiam deserunt ipsam quo
                error quia rerum. Alias qui provident eligendi enim
                exercitationem assumenda officia a iste architecto laboriosam
                fugiat ducimus molestiae possimus adipisci omnis cum eos cumque
                quos mollitia iure, velit et. Obcaecati eius illum minus autem
                rerum quo ad, illo eligendi voluptas veritatis dolores soluta
                voluptatem aliquam. Sequi officiis tempore, quos minus quibusdam
                culpa ad voluptatibus sunt sed nemo nihil eum cupiditate
                architecto error mollitia debitis a! Mollitia, id. Totam
                delectus veniam fugiat! Sit consequuntur totam accusamus minima
                eligendi consectetur aliquid, laudantium temporibus tenetur,
                quia aperiam repudiandae? Animi magni soluta in aliquid aliquam
                sapiente quod repellat nisi exercitationem maxime consequuntur
                recusandae quam repellendus facere quasi itaque quae officia,
                quis natus a minima excepturi quo. Quisquam illum quasi modi ex
                reprehenderit reiciendis vitae error, incidunt architecto, neque
                quae porro tempora quibusdam corrupti sapiente cupiditate
                officia consequuntur. Blanditiis incidunt ipsa sequi eveniet
                aliquid inventore qui laudantium! Deleniti, animi delectus, rem,
                vero libero totam nemo nam eaque quod fugit nobis beatae
                consectetur voluptatum commodi fugiat similique qui? Quod sit
                quo perferendis dolores voluptate?
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-footer" class="pg-item">Some footer column</div>
          </div>
        </article>
        <hr />
        <article>
          <div class="page-grid-2">
            <div id="p-header" class="pg-item left">
              <h2>Page Grid - 2 Columns</h2>
              <p>
                Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                Itaque, eveniet labore vero eaque ad quis sapiente? Excepturi
                corporis, facilis veritatis, consequuntur enim adipisci
                voluptatum molestiae ad odio blanditiis cupiditate esse
                praesentium placeat nesciunt suscipit iure quidem earum
                temporibus quaerat libero, quae autem maiores culpa. Ad omnis
                nulla modi asperiores molestias.
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column1" class="pg-item left">
              <h3>column 1</h3>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam
                eveniet, hic mollitia ab et sed nostrum beatae, recusandae
                asperiores reprehenderit, tempora provident praesentium quod
                velit tempore quaerat dignissimos. Expedita cumque autem vero
                eveniet aut alias non quod deleniti ipsa quae. Quas,
                necessitatibus rerum eius ducimus est laborum, atque alias
                optio, asperiores labore architecto ipsam! Magni!
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column2" class="pg-item left">
              <h3>column 2</h3>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. In
                tempora vitae consequatur! Maxime consequatur deserunt cum, modi
                ipsam sint, animi omnis ex sit autem libero eius, iste aperiam
                minus molestiae aspernatur! Explicabo ducimus eveniet beatae
                inventore corrupti dolore et tenetur?
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-footer" class="pg-item">Some footer column</div>
          </div>
        </article>
        <hr />
        <article>
          <div class="page-grid-3">
            <div id="p-header" class="pg-item left">
              <h2>Page Grid - 3 Columns</h2>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Corporis voluptatum, sed velit repellendus quod modi amet? Quos
                veritatis ad quod, sit tempora officiis minus reprehenderit aut
                quidem? Fugit, explicabo. Facilis explicabo minima nesciunt
                neque, eaque reprehenderit sapiente! Sunt accusantium recusandae
                cumque commodi animi tempore voluptas, tempora, eligendi,
                laudantium delectus quibusdam.
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;

              <Expander title="Expander" cstyle="shadow">
                <span
                  >Please note that your keyboard is not unlocked. You need to
                  enter your unlock code for more secured encryption</span
                ><br />
                <label>Secret code</label>
                <input
                  type="password"
                  name="password"
                  id="secret"
                  class="form-control"
                  placeholder="enter your code"
                  v-model="secretKey"
                  @keyup="refresh"
                />
              </Expander>
            </div>
            <div id="p-column1" class="pg-item left">
              <h3>column 1</h3>
              <p>
                Lorem ipsum dolor sit amet. Lorem ipsum dolor sit, amet
                consectetur adipisicing elit. Odit laboriosam dignissimos at
                totam sunt corrupti placeat quaerat vel officia explicabo quam
                commodi maiores deleniti laborum, dolorum sint, quisquam culpa
                eveniet? Vel veniam libero consequatur eius? Odit alias ab, quos
                recusandae dolorum ut quam nihil eum mollitia quo nisi aperiam
                laborum!
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column2" class="pg-item left">
              <br />
              <ExpanderSection
                title="Expander Section"
                cstyle="shadow"
                icon="home"
              >
                <h3>column 3</h3>
                <p>
                  Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                  Fugit culpa repellat velit doloremque corporis rerum cumque
                  delectus iste! Recusandae consequuntur voluptatem minima
                  similique animi repellendus quas atque id officia quo!
                </p>
                <router-link to="/" class="link-button">Some Link</router-link
                >&nbsp;&nbsp;
              </ExpanderSection>
            </div>
            <div id="p-column3" class="pg-item left">
              <Expander title="Expander" cstyle="shadow" icon="lock">
                <span
                  >Please note that your keyboard is not unlocked. You need to
                  enter your unlock code for more secured encryption</span
                ><br />
                <label>Secret code</label>
                <input
                  type="password"
                  name="password"
                  id="secret"
                  class="form-control"
                  placeholder="enter your code"
                  v-model="secretKey"
                  @keyup="refresh"
                />
              </Expander>
              <p>
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Fugit
                culpa repellat velit doloremque corporis rerum cumque delectus
                iste! Recusandae consequuntur voluptatem minima similique animi
                repellendus quas atque id officia quo!
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-footer" class="pg-item">Some footer column</div>
          </div>
        </article>
        <hr />
        <article>
          <div class="page-grid-12">
            <div id="p-header" class="pg-item left">
              <h2>Page Grid - 12 Columns</h2>
              <p>
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Non
                obcaecati quae optio tempora quaerat ducimus earum a nesciunt
                odio in quam voluptatibus ratione, soluta incidunt tempore!
                Dicta, consectetur. Molestias earum aperiam dicta architecto
                iusto? Rerum, velit aperiam officiis placeat corrupti voluptate,
                consequatur magni quasi saepe quaerat illum commodi tenetur
                eligendi odit vel sapiente quidem quo eveniet deserunt similique
                libero eaque ducimus! Aspernatur pariatur iure omnis corrupti
                aliquam, quam dignissimos at ad blanditiis, error sapiente
                natus, distinctio odio ipsa impedit deserunt deleniti soluta
                illo nobis. Suscipit porro praesentium esse sapiente mollitia,
                eveniet, nam dolorem libero atque molestiae maxime accusamus.
                Earum, eos?
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column1" class="pg-item left">
              <h3>column 1</h3>
              <p>
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Itaque
                placeat nisi alias sit iste tenetur inventore, modi dolorum
                ducimus repellat?
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column2" class="pg-item left">
              <h3>column 2</h3>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat
                voluptas illo suscipit quod, maiores magni unde earum, nulla
                reiciendis modi itaque eaque sit odit architecto perspiciatis
                corrupti quos minus laboriosam.
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-footer" class="pg-item">Some footer column</div>
          </div>
        </article>
        <hr />
        <article>
          <div class="page-grid-21">
            <div id="p-header" class="pg-item left">
              <h2>Page Grid - 21 Columns</h2>
              <p>
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nam
                sunt hic cum nostrum aut aperiam officiis odit porro earum
                rerum, ex maxime, illo quae voluptatibus delectus? Numquam hic
                quos non aperiam sunt, dolores, est quis voluptate nam dolorem
                neque accusamus voluptatum quibusdam pariatur possimus
                temporibus deserunt placeat repudiandae, quod qui iusto
                voluptatibus cupiditate laboriosam. Ex asperiores libero ut
                delectus dolor accusantium sequi, sed tenetur sunt. Adipisci
                accusantium necessitatibus enim placeat minima nesciunt corporis
                at cum aliquid voluptates laboriosam iste, magnam explicabo
                temporibus accusamus, fugit sunt repudiandae reprehenderit.
                Expedita laborum incidunt, dolores quisquam culpa debitis porro
                suscipit ab vero ipsum pariatur?
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column1" class="pg-item left">
              <h3>column 1</h3>
              <p>
                Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                Praesentium quibusdam harum nisi dignissimos omnis, consectetur
                minima voluptatem totam architecto distinctio.
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column2" class="pg-item left">
              <h3>column 2</h3>
              <p>
                Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                Delectus, voluptatum? Voluptatem ut magni numquam, placeat,
                maxime, consectetur ipsum labore necessitatibus recusandae
                itaque ab saepe possimus?
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-footer" class="pg-item">Some footer column</div>
          </div>
        </article>
        <hr />
        <article>
          <div class="page-grid-121">
            <div id="p-header" class="pg-item left">
              <h2>Page Grid - 121 Columns</h2>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid
                praesentium, cumque quo commodi voluptatum culpa neque pariatur
                perferendis quos? Harum, quasi sunt pariatur cupiditate mollitia
                excepturi distinctio ullam iure tempora?
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column1" class="pg-item left">
              <h3>column 1</h3>

              <nav>
                <p>
                  <a href="/html/">HTML</a> | <a href="/css/">CSS</a> |
                  <a href="/js/">JavaScript</a> | <a href="/python/">Python</a>
                </p>
              </nav>

              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column2" class="pg-item left">
              <h3>column 2</h3>
              <p>
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sequi
                vero esse labore, vitae quo sed, suscipit reiciendis maxime
                tempora nisi neque optio placeat repudiandae unde. Maxime
                recusandae ex fuga sed vitae labore, consectetur asperiores
                veritatis cum, atque saepe assumenda? Similique dolorem dolores
                a veritatis voluptatem voluptate mollitia repellat at sequi
                ipsam, facere illo cupiditate aliquid ratione quod. Eligendi
                quos dignissimos a quas aliquam ea odio iusto provident odit
                cumque? Earum dolor libero necessitatibus minima laborum quam
                perspiciatis voluptatibus accusantium dolorem nemo eveniet
                repudiandae architecto quidem facere eius quos, deserunt,
                tempore, explicabo alias commodi dolorum aliquid hic impedit
                praesentium. Labore, atque.
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column3" class="pg-item left">
              <h3>column 3</h3>
              <nav>
                <p>
                  <a href="/html/">HTML</a> | <a href="/css/">CSS</a> |
                  <a href="/js/">JavaScript</a> | <a href="/python/">Python</a>
                </p>
              </nav>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-footer" class="pg-item">Some footer column</div>
          </div>
        </article>
      </main>
    </div>
  </div>

  <!-- <ul v-for="(item, index) in dataSet.response" :key="index">
            <li>{{ index }} : {{ item.firstname + " " + item.lastname }}</li>
           </ul> -->
</template>

<script lang="ts">
import { APIUtility } from "@/services/api";
import { defineComponent, onBeforeMount, onUpdated, reactive, ref } from "vue";
import Loader from "@/components/common/Loader.vue"; // @ is an alias to /src
import Expander from "@/components/common/Expander.vue";
import ExpanderSection from "@/components/common/ExpanderSection.vue";

export default defineComponent({
  name: "Template",
  props: {
    msg: String,
  },
  components: { Loader, Expander, ExpanderSection },
  emits: ["alert"],
  setup(props, { emit }) {
    const isLoading = ref(true);
    let dataSet = reactive({
      response: "",
    });
    let apiUtil = new APIUtility();
    isLoading.value = true;
    const refresh = () => {
      isLoading.value = true;
      apiUtil
        .getData()
        .then((response: any) => {
          dataSet.response = response["data"];
        })
        .catch((e: any) => {
          emit("alert", "Error", "Error loading the data");
        });
    };
    onBeforeMount(() => {
      refresh();
    });
    onUpdated(() => {
      isLoading.value = false;
    });

    refresh();
    return { refresh, isLoading, dataSet };
  },
});
</script>

