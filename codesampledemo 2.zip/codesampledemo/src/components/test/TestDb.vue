<template>
  <div id="wrapper">
    <!-- Menu -->
    <div id="main">
      <!-- page -->
      <!-- <Loader :show="isLoading" type="bar" /> -->
      <article class="page">
        <header>
          <div class="title">
            <h1>Database Test</h1>
          </div>
          <div class="meta">
            <div></div>
          </div>
        </header>
        <div class="dtable">
          <SmartTable
            :data="dataSet.response"
            id="doc_id"
            @deleteRow="deleteRow"
            @updateRow="updateRow"
            @insertRow="insertRow"
          />
        </div>
      </article>
    </div>
  </div>
</template>

<script lang="ts">
import { FDBUtility } from "@/services/fdbutility";
import { defineComponent, reactive, ref } from "vue";
import Loader from "@/components/common/Loader.vue"; // @ is an alias to /src
import SmartTable from "@/components/common/SmartTable.vue"; // @ is an alias to /src

export default defineComponent({
  name: "TestDB",
  props: {
    msg: String,
  },
  components: { Loader, SmartTable },
  emits: ["alert"],
  setup(_, { emit }) {
    const isLoading = ref(true);
    let fdb = new FDBUtility("feedback");
    let dataSet = reactive({ response: [] });

    isLoading.value = true;
    const refresh = () => {
      isLoading.value = true;
      fdb
        .getAll()
        .then((response: any) => {
          dataSet.response = response;
          isLoading.value = false;
        })
        .catch((e: any) => {
          emit("alert", "Error", "Error loading the data");
          isLoading.value = false;
        });
    };
    refresh();

    const deleteRow = (rowId: any) => {
      isLoading.value = true;
      //alert("Deleting -" + rowId);
      fdb
        .delete(rowId)
        .then((response: any) => {
          refresh();
          emit("alert", "Delete", "Deleted successfully");
        })
        .catch((e: any) => {
          emit("alert", "Error", "Error loading the data");
          isLoading.value = false;
        });
    };
    const insertRow = (rowId: any, payload: any) => {
      isLoading.value = true;
      fdb
        .add(payload)
        .then((response: any) => {
          refresh();
          emit("alert", "Add", "Row addedd successfully");
        })
        .catch((e: any) => {
          emit("alert", "Error", "Error loading the data");
          isLoading.value = false;
        });
    };
    const updateRow = (rowId: any, payload: any) => {
      isLoading.value = true;
      fdb
        .update(rowId, payload)
        .then((response: any) => {
          emit("alert", "Add", "Row updated successfully");
          refresh();
        })
        .catch((e: any) => {
          emit("alert", "Error", "Error loading the data");
          isLoading.value = false;
        });
    };

    return { refresh, isLoading, dataSet, deleteRow, updateRow, insertRow };
  },
});
</script>
<style lang="scss" scoped>
.dtable {
  width: 100%;
}
</style>
