<template>
  <div id="wrapper">
    <!-- Menu -->
    <div id="main">
      <!-- page -->
      <Loader :show="isLoading" type="bar" />
      <article class="page">
        <header>
          <div class="title">
            <h1>API Test</h1>
            <p>Total records found: {{ dataSet.response.length || 0 }}</p>
          </div>
          <div class="meta">
            <time class="published" datetime="2015-11-01"
              >November 1, 2015</time
            >
            <a @click="refresh" class="button"
              ><fa class="icon" icon="history"
            /></a>
          </div>
        </header>
        <ul v-for="(item, index) in dataSet.response" :key="index">
          <li>{{ index }} : {{ item.firstname + " " + item.lastname }}</li>
        </ul>
      </article>
    </div>
  </div>
</template>

<script lang="ts">
import { APIUtility } from "@/services/api";
import { defineComponent, onMounted, reactive, ref } from "vue";
import Loader from "@/components/common/Loader.vue"; // @ is an alias to /src

export default defineComponent({
  name: "TestApi",
  props: {
    msg: String,
  },
  components: { Loader },
  emits: ["alert"],
  setup(_, { emit }) {
    const isLoading = ref(true);
    let dataSet = reactive({
      response: "",
    });
    let apiUtil = new APIUtility();
    isLoading.value = true;
    const refresh = () => {
      isLoading.value = true;
      apiUtil
        .getData()
        .then((response: any) => {
          dataSet.response = response["data"];
          isLoading.value = false;
        })
        .catch((e: any) => {
          emit("alert", "Error", "Error loading the data");
          isLoading.value = false;
        })
        .finally(() => {
          //isLoading.value = false;
        });
    };

    refresh();
    return { refresh, isLoading, dataSet };
  },
});
</script>
