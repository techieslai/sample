<template>
  <div id="wrapper">
    <div class="flex center">
      <h3>Welcome to Jumble game board!</h3>
      <br />
      <span
        >Your goal is to order the numbers on the board by moving the tiles
        around. Try to complete it faster with minimal moves
      </span>
      <br />
      <br />
      <b>Choose the board style</b><br />
      <div class="flex center">
        <a @click="newGame(3)" class="icon tool"> 3X3 </a>&nbsp;
        <a @click="newGame(4)" class="icon tool"> 4X4 </a>&nbsp;
        <a @click="newGame(5)" class="icon tool"> 5X5 </a>
      </div>
    </div>

    <div class="flex center">
      <div
        style=""
        class="flex center"
        v-if="!gameOver && timer != '00:00'"
      >
        <span class="tool">
          Timer : <b>{{ timer }}</b> </span
        >&nbsp;
        <span class="tool">
          Moves : <b>{{ moves }}</b> </span
        >&nbsp;
      </div>
      <div
        style="background: lightgreen; border: 1px solid green"
        class="flex center"
        v-if="gameOver"
      >
        <span
          ><b>Congratulations!</b> You solved it in <b>{{ timer }}</b> seconds
          using <b>{{ moves }}</b> moves</span
        >
      </div>
      <table class="jboard">
        <tr v-for="row in size" :key="row">
          <template v-for="col in size" :key="col">
            <td class="coinbase center" @click="move(row, col)">
              <span class="">
                {{
                  coins[(row - 1) * size + col - 1].coin == 0
                    ? ""
                    : coins[(row - 1) * size + col - 1].coin
                }}</span
              >
            </td>
          </template>
        </tr>
      </table>
    </div>
  </div>
</template>

<script lang="ts">
import { Utility } from "@/services/utility";
import { defineComponent, ref } from "vue";

export default defineComponent({
  name: "JumbleBoard",
  props: {
    msg: String,
  },
  setup() {
    let util = new Utility();
    let coins = ref();
    let size = ref();
    let moves = ref(0);
    let timer = ref("00:00");
    let timerClock = ref();
    let gameOver = ref(false);

    const newGame = (s: number) => {
      size.value = s;
      coins.value = util.arrayInitialize(size.value * size.value);
      coins.value = util.arrayRandomize(coins.value);
      moves.value = 0;
      startTimerClock();
    };

    const move = (row: number, col: number) => {
      let clickPos = (row - 1) * size.value + col - 1;
      let emptyPos: number = 0;
      for (let i = 0; i < coins.value.length; i++) {
        if (coins.value[i].coin == 0) emptyPos = i;
      }
      //alert(clickPos % size)
      if (
        emptyPos == clickPos + size.value ||
        emptyPos == clickPos - size.value ||
        emptyPos == clickPos + size.value ||
        (clickPos % size.value != size.value - 1 && emptyPos == clickPos + 1) ||
        (clickPos % size.value != 0 && emptyPos == clickPos - 1)
      ) {
        let clickCoin = coins.value[emptyPos];
        coins.value[emptyPos] = coins.value[clickPos];
        coins.value[clickPos] = clickCoin;
        moves.value = moves.value + 1;
      }
      gameOver.value = isGameOver();
      if (gameOver.value) stopTimerClock();
    };

    const isGameOver = () => {
      let gameOver = true;
      for (let i = 1; i < coins.value.length; i++) {
        if (coins.value[i - 1].coin != i) gameOver = false;
      }
      return gameOver;
    };

    const startTimerClock = () => {
      gameOver.value = false;
      let startTime = new Date().getTime();
      stopTimerClock();
      timerClock.value = setInterval(function () {
        let now = new Date().getTime();
        let t = now - startTime;
        let days = Math.floor(t / (1000 * 60 * 60 * 24));
        let hours = Math.floor((t % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        let minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
        let seconds = Math.floor((t % (1000 * 60)) / 1000);
        timer.value = minutes + ":" + seconds;
      }, 1000);
    };

    const stopTimerClock = () => {
      return clearInterval(timerClock.value);
    };

    return {
      coins,
      size,
      move,
      newGame,
      moves,
      timer,
      gameOver,
    };
  },
});
</script>

<style lang="scss">
.jboard {
  width: 1px;
  height: 1px;
  margin: auto;
  td {
    border: 1px solid $primary-500;
    box-shadow: 6px 6px 8px 0 rgba(0, 0, 0, 0.25),
      -4px -4px 2px 0 rgba(255, 255, 255, 0.3);
    margin: auto;
    font-size: 1.7em;
    cursor: pointer;
  }
  td:hover {
    background: rgb(190, 248, 245);
  }
}
.flex {
  margin-bottom: 0.5em;
  width: 100%;
  display: block;
}
</style>

