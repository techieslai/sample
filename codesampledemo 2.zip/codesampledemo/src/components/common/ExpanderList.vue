<template>
  <div>
    <div @click="show = !show" class="expand-grid">
      <div :class="show ? 'expand' : 'noexpand'">
        {{ $props.title }}
      </div>
      <div v-if="!show" @click="show = false" class="right">
        <fa class="icom-md" icon="chevron-right" />
      </div>
      <div v-if="show" @click="show = true" class="right">
        <fa class="icom-md" icon="chevron-down" />
      </div>
    </div>
    <transition name="fade">
      <p v-if="show" class="content"><slot></slot></p>
    </transition>
  </div>
</template>
<script lang="ts">
import { defineComponent, ref, watch } from "vue";
export default defineComponent({
  name: "ExpanderList",
  props: {
    title: String,
  },
  setup(props, { emit }) {
    const show = ref(false);
    watch(props, () => {});
    const close = () => {};
    return { close, show };
  },
});
</script>

<style lang="scss">
.expand-grid {
  display: grid;
  grid-template-columns: 4fr 1fr;
  border-left: 2px solid $accent-800;
  background-color: $primary-100;
  width: 100%;
  padding: 0.5em;
  font-size: 1.2em;
  cursor: pointer;
  border-bottom: 2px solid $white;
}

.expand {
  font-weight: bold;
}
.noexpand {
  font-weight: normal;
}
.noexpand:hover {
  color: $accent-800;
}
.content {
  border: 1px solid $primary-100;
  padding: 1em;
  font-size: 1em;
}
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>