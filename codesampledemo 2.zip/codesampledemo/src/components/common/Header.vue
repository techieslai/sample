<template>
  <div>
    <!-- Header -->
    <header id="header" class="shadow-down">
      <div class="logo">
        <a href="/"> <img src="@/assets/images/logo.png" /> </a>
      </div>
      <h1 class="title">{{ APP_NAME }}</h1>
      <nav class="links">
        <ul class="header-links">
          <template v-for="item in menu" :key="item.id">
            <li>
              <router-link :to="item.link"> {{ item.title }}</router-link>
            </li>
          </template>
        </ul>
      </nav>
      <div>
        <ul>
          <li class="menu-icon-link">
            <div class="menu-hide">
              <a @click="menuClicked('MAIN MENU')" class="menu-icon-link">
                <fa class="icon-sm" icon="bars"></fa
              ></a>
            </div>
          </li>
          <li class="menu-icon-link" v-if="!isLoggedIn">
            <a @click="menuClicked('PROFILE')" class="menu-icon-link">
              <fa class="icon-sm" icon="user"></fa
            ></a>
          </li>
          <li class="menu-icon-link" v-if="isLoggedIn">
            <div class="menu" :title="profile.email">
              <a
                @click="menuClicked('PROFILE')"
                class="menu-icon-link user-login"
              >
                <fa class="icon-sm" icon="user"></fa
              ></a>
              <span class="user-badge">{{ profile.name }}</span>
            </div>
          </li>

          <!-- <li>
            <div class="login-element">
              <router-link to="/login" class="link-login">LOGIN</router-link>
            </div>
          </li> -->
          <!-- <li>
            <div class="user">
              <a @click="menuClicked('PROFILE')" class="link">
                <fa class="icon-sm" icon="icon" type="jpg"
                  ><label>Suresh Kotinadhuni </label></fa
                ></a
              >
            </div>
          </li> -->
        </ul>
      </div>
    </header>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, ref, watch } from "vue";
import SideNav from "@/components/common/SideNav.vue";
import store from "@/store";

import {
  APP_NAME,
  AUTH_USER,
  MAIN_MENU,
  MAIN_USER_MENU,
} from "@/data/settings";

export default defineComponent({
  name: "Header",
  components: { SideNav },
  props: { refresh: String },
  emits: ["menu"],
  setup(props, { emit }) {
    const menu = ref({});
    const menuClicked = (title: string) => {
      if (isLoggedIn.value) emit("menu", title, "user");
      else emit("menu", title, "");
    };

    const isLoggedIn = ref(false);
    const profile = reactive(<{ name: string; email: string }>{
      name: "",
      email: "",
    });
    watch(props, () => {
      refreshHeader();
    });
    const refreshHeader = () => {
      if (store.getters.isLoggedIn) {
        isLoggedIn.value = true;
        profile.name = store.getters.profile.name;
        profile.email = store.getters.profile.email;
        menu.value = MAIN_USER_MENU;
      } else {
        isLoggedIn.value = false;
        menu.value = MAIN_MENU;
      }
    };
    refreshHeader();
    return {
      menuClicked,
      APP_NAME,
      MAIN_MENU,
      isLoggedIn,
      menu,
      profile,
    };
  },
});
</script>

<style lang="scss" scoped>
.title {
  font-size: 1.2em;
  margin-right: 0em;
}
.menu-icon-link {
  color: $menu-icon-color;
  margin-right: 0.5em;
}
.menu-icon-link:hover {
  color: $link-hover-color;
  transition: 0.3s ease-in-out;
}
.user-login {
  color: $accent-900;
  text-align: center;
}
.menu {
  position: relative;
  margin-right: 1em;
  margin-top: 0.3em;
  .user-badge {
    position: absolute;
    margin-left: -0.6em;
    margin-top: -0.5em;
    color: $primary-900;
    font-weight: 900;
    text-shadow: 2px 2px 3px $black-400;
  }
}
</style>

