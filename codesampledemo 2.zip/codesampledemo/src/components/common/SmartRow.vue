<template>
  <div class="s-table-container">
    <div class="grid-container-popup">
      <div class="grid-item left">
        <h3>Feedback Item</h3>
      </div>
    </div>
    <div class="s-table-grid-tool">
      <div>
        <span><fa class="icon-sm" icon="th" /></span>
        <h4 style="display: inline; margin-left: 0.3em">
          Feedback Item Details
        </h4>
      </div>
      <div class="right" v-if="viewType === 'VIEW'">
        <a @click="showRecord(-1)" class="tool"
          ><fa class="icon-sm fa" icon="arrow-left" /></a
        >&nbsp;&nbsp;
        <a @click="showRecord(1)" class="tool"
          ><fa class="icon-sm fa" icon="arrow-right"
        /></a>
      </div>
    </div>

    <div class="count" v-if="viewType === 'VIEW'">
      <h6>Showing item {{ cIndex + 1 }} of {{ $props.data.length || 0 }}</h6>
    </div>

    <!-- <div class="">
      <a @click="toolClick('ADD', 0, {})" class="tool">Add Item</a>
    </div> -->
    <!-- <div class="">
      <div class="control-search">
        <div class="wrapper">
          <img
            class="search-icon"
            src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDU2Ljk2NiA1Ni45NjYiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDU2Ljk2NiA1Ni45NjY7IiB4bWw6c3BhY2U9InByZXNlcnZlIiB3aWR0aD0iMTZweCIgaGVpZ2h0PSIxNnB4Ij4KPHBhdGggZD0iTTU1LjE0Niw1MS44ODdMNDEuNTg4LDM3Ljc4NmMzLjQ4Ni00LjE0NCw1LjM5Ni05LjM1OCw1LjM5Ni0xNC43ODZjMC0xMi42ODItMTAuMzE4LTIzLTIzLTIzcy0yMywxMC4zMTgtMjMsMjMgIHMxMC4zMTgsMjMsMjMsMjNjNC43NjEsMCw5LjI5OC0xLjQzNiwxMy4xNzctNC4xNjJsMTMuNjYxLDE0LjIwOGMwLjU3MSwwLjU5MywxLjMzOSwwLjkyLDIuMTYyLDAuOTIgIGMwLjc3OSwwLDEuNTE4LTAuMjk3LDIuMDc5LTAuODM3QzU2LjI1NSw1NC45ODIsNTYuMjkzLDUzLjA4LDU1LjE0Niw1MS44ODd6IE0yMy45ODQsNmM5LjM3NCwwLDE3LDcuNjI2LDE3LDE3cy03LjYyNiwxNy0xNywxNyAgcy0xNy03LjYyNi0xNy0xN1MxNC42MSw2LDIzLjk4NCw2eiIgZmlsbD0iIzAwMDAwMCIvPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8L3N2Zz4K"
          />
          <input
            placeholder="Search"
            type="text"
            class="search"
            v-model="search"
            @keyup="searchData"
          />
        </div>
      </div>
    </div> -->

    <div class="s-table smart-table">
      <div class="s-tableHeading">
        <div class="s-tableRow">
          <template v-for="(col, hind) in dataView" :key="hind">
            <div
              class="s-tableHead"
              v-if="col.config.type != 'hidden'"
              @click="sortClick(col.attribute)"
            >
              {{ col.config.title }}
              <span class="icon-arrow">
                <fa
                  v-if="sort === col.attribute && sortOrder"
                  class="none"
                  icon="long-arrow-alt-up"
                />
                <fa
                  v-if="sort === col.attribute && !sortOrder"
                  class="none"
                  icon="long-arrow-alt-down"
                />
              </span>
            </div>
          </template>
          <div class="s-tableHead">Actions</div>
        </div>
      </div>
      <div class="s-tableBody">
        <template v-for="(row, rind) in data" :key="rind">
          <div class="s-tableRow">
            <template v-for="(col, cind) in dataView" :key="cind">
              <div class="s-tableCell" v-if="col.config.type != 'hidden'">
                <span class="small-title">{{ col.config.title }}</span>
                <span class="data" v-if="viewType === 'VIEW'">
                  <div class="s-tableData">
                    <span
                      :class="
                        col.config.style +
                        ' ' +
                        col.attribute +
                        '_' +
                        row[col.attribute].toLowerCase().replaceAll(' ', '')
                      "
                      >{{ row[col.attribute] }}</span
                    >
                  </div>
                </span>
                <input
                  v-if="viewType != 'VIEW'"
                  type="text"
                  :name="col.attribute"
                  :id="col.attribute"
                  class="form-control"
                  :placeholder="'enter value ' + col.attribute"
                  v-model="payload[col.attribute]"
                />
              </div>
            </template>
            <!-- <div class="s-tableCell toolcell">
              <a @click="toolClick('VIEW', rind, {})" class="tool">
                <fa class="icon-sm fa" icon="external-link-square-alt" /> </a
              >&nbsp;
              <a @click="toolClick('EDIT', rind, {})" class="tool">
                <fa class="icon-sm fa" icon="edit" /> </a
              >&nbsp;
              <a @click="toolClick('DELETE', rind, editPayload)" class="tool">
                <fa class="icon-sm fa red" icon="trash-alt" />
              </a>
            </div> -->
          </div>
        </template>
      </div>
    </div>

    <div class="tfooter">
      <div>
        <div class="grid-container-3 htools">
          <div class=""></div>
          <div class=""></div>
          <div class="right">
            <p>
              <a
                class="link-button cancel"
                v-if="viewType === 'VIEW'"
                @click="$emit('close')"
                >Close</a
              >
              <a
                class="link-button cancel"
                v-if="viewType === 'EDIT' || viewType === 'ADD'"
                @click="$emit('close')"
                >Cancel</a
              >
              <a
                class="link-button"
                v-if="viewType === 'EDIT' || viewType === 'ADD'"
                @click="save"
                >Save</a
              >
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import {
  defineComponent,
  onBeforeMount,
  onBeforeUpdate,
  onMounted,
  reactive,
  ref,
  watch,
  watchEffect,
} from "vue";
import Loader from "@/components/common/Loader.vue"; // @ is an alias to /src
import { Utility } from "@/services/utility";
import { DATA_DICTIONARY } from "@/data/dictionary";
import Context from "@/components/common/Context.vue";
import Modal from "@/components/common/Modal.vue";
import { DATASET } from "@/data/mappings";

export default defineComponent({
  name: "SmartRow",
  props: {
    data: Array,
    view: String,
    type: String,
    tools: String,
    index: Number,
    id: String,
    table: String,
  },
  emits: ["save", "close"],
  components: { Loader, Context, Modal },
  setup(props, { emit }) {
    let record = {
      title: "",
      category: "",
    };
    let payload = ref(props.data);
    let payloadId = ref(props.id);
    const rkey = ref(0);
    const viewType = ref();
    const isRowOpen = ref(false);
    const isLoading = ref(true);
    let util = new Utility();
    const dataView = ref();
    dataView.value = [];
    const dataColumns = ref([{}]);
    const data = ref();
    let dataSelect = ref();
    const search = ref();
    const sort = ref();
    const sortOrder = ref(false);
    let cIndex = ref();
    cIndex.value = props.index || 0;
    const refresh = () => {
      let x = new Array();
      viewType.value = props.type;
      data.value = props.data;
      if (data.value.length == 0) {
        payload.value = <any>record;
      } else payload.value = data.value[cIndex.value];
      x.push(payload.value);
      data.value = x;
      dataColumns.value = <any[]>(
        util.dictionary(props.table || "", Object.keys(data.value[0]).sort())
      );
      dataView.value = <any[]>(
        util.dictionary(props.table || "", Object.keys(data.value[0]).sort())
      );
      if ((props.view || "") != "") {
        let view = util.getDatasetByKeyVal(DATASET, "view", <string>props.view);
        dataColumns.value = <any[]>(
          util.dictionary(props.table || "", view.config.columns)
        );
        dataView.value = <any[]>(
          util.dictionary(props.table || "", view.config.columns)
        );
      }
      isLoading.value = false;
    };

    const sortClick = (attr: string) => {
      sortOrder.value = !sortOrder.value;
      sort.value = attr;
      data.value = util.arraySort(data.value, attr, sortOrder.value);
    };
    const showRecord = (ind: number) => {
      cIndex.value = cIndex.value + ind;
      cIndex.value = cIndex.value <= 0 ? 0 : cIndex.value;
      cIndex.value =
        cIndex.value >= <number>props.data?.length - 1
          ? <number>props.data?.length - 1
          : cIndex.value;
      refresh();
    };
    const searchData = () => {
      if (search.value.length > 2) {
        data.value = util.arrayFilterPatternMatch(
          <any[]>props.data,
          search.value
        );
      } else {
        data.value = props.data;
      }
    };

    const save = () => {
      let pyld: any = payload.value;
      let rowId: string = <string>props.id;
      emit("save", props.type, pyld[rowId], pyld);
    };

    const edit = () => {
      viewType.value = "EDIT";
    };

    watch(props, () => {
      refresh();
      rkey.value = rkey.value + 1;
    });

    onBeforeMount(() => {
      refresh();
    });

    return {
      edit,
      isLoading,
      data,
      dataColumns,
      dataView,
      save,
      rkey,
      viewType,
      dataSelect,
      isRowOpen,
      searchData,
      search,
      sortClick,
      sort,
      sortOrder,
      cIndex,
      showRecord,
      payload,
    };
  },
});
</script>
<style lang="scss" scoped>
div.smart-table {
  width: 100%;
  text-align: left;
  border-top: 2px solid $accent-900;
  border-bottom: 1px solid $primary-500;
}
div.count {
  width: 100%;
  text-align: center;
  margin-bottom: 0.5em;
  h6 {
    font-size: 0.9em;
  }
}
.s-table.smart-table .s-tableCell,
.s-table.smart-table .s-tableHead {
  padding: 5px 10px;
}
.s-table.smart-table .s-tableBody .s-tableCell {
  //font-size: 15px;
  padding-top: 0.5em;
  padding-bottom: 0.5em;
}
.s-table.smart-table .s-tableHeading {
  background: $primary-500;
  background: -moz-linear-gradient(
    top,
    $primary-100 0%,
    $primary-200 66%,
    $primary-500 100%
  );
  background: -webkit-linear-gradient(
    top,
    $primary-100 0%,
    $primary-200 66%,
    $primary-500 100%
  );
  background: linear-gradient(
    to bottom,
    $primary-100 0%,
    $primary-200 66%,
    $primary-500 100%
  );
}
.s-table.smart-table .s-tableHeading .s-tableHead {
  //font-size: 15px;
  font-weight: bold;
  color: $black-900;
  text-align: left;
  padding: 5px 10px;
}
.smart-table .tableFootStyle {
  //font-size: 15px;
  font-weight: bold;
  color: $black-800;
}

.smart-table .tableFootStyle {
  //font-size: 15px;
  background: $primary-100;
}
.smart-table .tableFootStyle .links {
  text-align: center;
  padding: 0.5em;
}
.smart-table .tableFootStyle .links a {
  display: inline-block;
  background: $accent-800;
  color: $white;
  padding: 5px 10px 2px;
  border-radius: 5px;
  text-decoration: none;
  margin: auto;
}
.smart-table .tableFootStyle .links a:hover {
  background: $accent-900;
  transition: 0.2s ease-in-out;
}
.smart-table.outerTableFooter {
  border-top: none;
}
.smart-table.outerTableFooter .tableFootStyle {
  padding: 5px;
}
.s-tableHead {
  cursor: pointer;
}
.s-tableHead:hover {
  cursor: pointer;

  opacity: 60%;
}
.s-table {
  display: table;
}
.s-tableRow {
  display: table-row;
}
.s-tableHeading {
  display: table-header-group;
}
.s-tableCell,
.s-tableHead {
  display: block;
}
.s-tableHeading {
  display: table-header-group;
}
.s-tableFoot {
  display: table-footer-group;
}
.s-tableBody {
  display: table-row-group;
}
.toolcell {
  text-align: center;
  width: 150px;
}
.small-title {
  display: none;
  color: $black-900;
}
.control-search {
  .wrapper {
    position: relative;
    display: flex;
    min-width: 100px;
  }
  .search {
    // border: 1px solid grey;
    height: 25px;
    width: 100%;
    padding: 2px 23px 2px 30px;
    outline: 0;
    background-color: $accent-100;
    border: 0px;
  }
  .search-icon {
    position: absolute;
    top: 10px;
    left: 8px;
    width: 15px;
  }
  .clear-icon {
    position: absolute;
    top: 15px;
    right: 8px;
    width: 12px;
    cursor: pointer;
    visibility: hidden;
  }
  .search:hover,
  .search:focus {
    background-color: $accent-100;
  }
}

.data {
  //font-size: 15px;
}
.icon-arrow {
  color: $accent-900;
}
.s-tableHeading {
  display: none;
}
.small-title {
  display: block;
  color: $black-800;
  font-weight: 600;
  // font-size: 14px;
}
.s-tableCell,
.s-tableHead {
  display: block;
}
.toolcell {
  background: $primary-100;
  width: 100%;
  border-bottom: 2px solid $primary-500;
}

.s-table-container {
  // border: 1px solid $primary-500;
  padding: 1em;
}
.s-table-grid-tool {
  * {
    padding: 0;
    margin: 0;
  }
  margin-top: 1em;
  margin-bottom: 1em;
  display: grid;
  grid-template-columns: 3fr 1fr;

  span {
    padding: 5px;
    color: $primary-600;
  }
}
@media only screen and (max-width: 760px),
  (min-device-width: 768px) and (max-device-width: 1024px) {
  .s-tableHeading {
    display: none;
  }
  .small-title {
    display: block;
  }
  .s-table.smart-table .s-tableBody .s-tableCell {
    //font-size: 15px;
    padding-top: 0.5em;
    padding-bottom: 0.5em;
  }

  .s-tableCell,
  .s-tableHead {
    display: block;
    padding: 0;
    margin: 0;
  }
  .toolcell {
    background: $primary-100;
    width: 100%;
    border-bottom: 2px solid $primary-500;
  }
  .data {
    //font-size: 15px;
  }
}
</style>