<template>
  <div class="tab-wrapper">
    <div class="nav-grid">
      <ul>
        <li v-for="(item, ind) in tabs" :key="ind" @click="selectTab(ind)">
          <div v-if="selected.id === item" class="nav selected">
            {{ titles[ind] || item }}
          </div>
          <div v-if="selected.id != item" class="nav">
            {{ titles[ind] || item }}
          </div>
        </li>
      </ul>
      <div class="content">
        <slot />
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { provide, defineComponent, ref, watch } from "vue";
export default defineComponent({
  name: "TabView",
  props: { tabs: String, titles: String },
  setup(props) {
    const tabs = ref(<any[]>props.tabs?.split(","));
    const titles = ref(<any[]>props.titles?.split(","));
    const selected = ref({
      id: tabs.value[0],
      title: titles.value[0],
      class: "nav selected",
    });
    const selectTab = (ind: number) => {
      selected.value = {
        id: tabs.value[ind],
        title: titles.value[ind],
        class: "nav selected",
      };
    };
    watch(props, () => {});
    provide("selected", selected);
    return { tabs, titles, selected, selectTab };
  },
});
</script>

<style lang="scss" scoped>
.tab-wrapper {
  padding: 0.5em;
  border: 1px solid $primary-100;
}
.nav-grid {
  display: grid;
  grid-template-columns: 1fr 5fr;
  font-size: 0.9em;
  width: 100%;
  color: $accent-900;
  .content {
    padding: 1em;
    border: $primary-100;
    color: $primary-800;
  }
  .nav {
    font-size: 0.9em;
    font-weight: 500;
    padding: 0.3em 1em;
    background-color: $white;
    border-left: 2px solid $white;
    border-top: 2px solid $white;
    border-right: 2px solid $white;
    border-bottom: 2px solid $white;
    cursor: pointer;
  }
  .nav:hover {
    border-left: 2px solid $accent-600;
    border-top: 2px solid $white;
    border-right: 2px solid $white;
    border-bottom: 2px solid $white;
  }
  .selected {
    background-color: $white;
    border-left: 2px solid $accent-800;
    font-weight: bold;
  }
}
@media only screen and (max-width: 1024px), (max-device-width: 1024px) {
  .nav-grid {
    display: grid;
    grid-template-columns: 1fr;
    font-size: 0.9em;
    width: 100%;
    color: $accent-800;
    ul {
      list-style-type: none;
      display: flex;
      margin: auto;
    }
    .nav {
      font-size: 0.9em;
      font-weight: 500;
      padding: 0.3em 1em;
      background-color: $white;
      border-left: 2px solid $white;
      border-top: 2px solid $white;
      border-right: 2px solid $white;
      border-bottom: 2px solid $white;
      cursor: pointer;
    }
    .nav:hover {
      border-left: 2px solid $white;
      border-top: 2px solid $white;
      border-right: 2px solid $white;
      border-bottom: 2px solid $accent-600;
    }
    .selected {
      background-color: $white;
      border-bottom: 2px solid $white;
      font-weight: bold;
      border-bottom: 2px solid $accent-800;
    }
  }
}
</style>