<template>
  <transition name="msg-fade">
    <div key="3" v-if="show" class="callout">
      <div class="callout-header">{{ title }}</div>
      <span
        class="close"
        @click="
          show = false;
          messages = [];
        "
        >&times;</span
      >
      <div class="callout-container">
        <div>
          <fa class="icon-md" icon="times-circle" />
        </div>
        <div>
          <ul>
            <li v-for="(msg, i) in messages" :key="i">{{ msg }}</li>
          </ul>
          <span class="popuptext" id="myPopup">
            <slot></slot>
          </span>
        </div>
      </div>
    </div>
  </transition>
</template>

<script lang="ts">
import { defineComponent, ref, watch } from "vue";
export default defineComponent({
  name: "Callout",
  props: {
    title: String,
    msgs: Array,
    style: {},
    refresh: Number,
  },
  emits: ["result"],
  setup(props) {
    const show = ref(false);
    const messages = ref([]);
    watch(props, () => {
      messages.value = <any>props.msgs;
      let cnt: number = messages.value.length || 0;
      if (cnt > 0) {
        show.value = true;
      } else show.value = false;
    });
    return { show, messages };
  },
});
</script>
<style lang="scss" scoped>
#myPopup {
  padding: 0.5em;
  background-color: $yellow-200;
  color: $red-800;
  font-size: 13px;
  display: block;

  ul > li {
    list-style-type: square;
    margin-left: 1em;
  }
}
// .errorbox {
//   display: absolute;
//   z-index: 500;
//   left: 0;
//   top: 0;
// }

.callout {
  position: fixed;
  top: 5em;
  right: 1em;
  max-width: 400px;
  box-shadow: 2px 3px 5px $gray-500;
  border: 1px solid $black-500;
  width: 100%;
}

.callout-header {
  padding: 0.2em 1em;
  background: $red-800;
  font-size: 20px;
  color: $white;
}

.callout-container {
  position:relative;
  padding: 1em;
  background-color: $yellow-100;
  color: black;
  display: grid;
  grid-template-columns: 1fr 5fr;
}

.close {
  position: absolute;
  top: 0;
  right: 0;
  margin-top: 0.3em;
  margin-right: -0.2em;
  border-radius: 10px;
  width: 40px;
  height: 40px;
  color: white;
  font-size: 2em;
  cursor: pointer;
}
.close:hover {
  color: $primary-200;
}
</style>