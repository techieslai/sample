<template>
  <div class="content-wraper" v-if="selectedObj.id === $props.id">
    <h5>{{ selectedObj.title }}</h5>
    <div class="content">
      <slot />
    </div>
  </div>
</template>
<script lang="ts">
import { inject, defineComponent, ref, watch, reactive } from "vue";
export default defineComponent({
  name: "Tab",
  props: { id: String },
  setup(props) {
    const selectedObj = ref(<any>inject("selected"));
    watch(props, () => {});
    const close = () => {};
    return { selectedObj };
  },
});
</script>

<style lang="scss" scoped>
.content-wraper {
  padding: 0.2em 0.5em;
  h5 {
    margin-bottom: 0.5em;
  }
  .content {
  }
}
</style>