<template>
  <transition name="msg-fade">
    <div v-if="show" class="callout">
      <div class="callout-header">{{ title }}</div>
      <span class="closebtn" @click="closeMe">×</span>
      <div class="callout-container">
        <div>
          <fa class="icon-md" icon="times-circle" />
        </div>
        <div @click="closeMe">
          <span class="popuptext" id="myPopup">
            <ul>
              <template v-for="(err, index) in errors" :key="index">
                <li>{{ err.message }}</li>
              </template>
            </ul>
          </span>
        </div>
      </div>
    </div>
  </transition>
</template>

<script lang="ts">
import { defineComponent, ref, watch } from "vue";
export default defineComponent({
  name: "FormValidation",
  props: {
    title: String,
    validate: Boolean,
    rules: Object,
    payload: Object,
    refresh: Number,
  },
  emits: ["result"],
  setup(props, { emit }) {
    const show = ref(false);
    const RuleConfig = [
      {
        key: "REQUIRED",
        rule: "'@'.length === 0",
        message: "@ is required",
      },
      {
        key: "MIN",
        rule: "'@'.length < #1",
        message: "@ should be more than #1 characters",
      },
      {
        key: "MAX",
        rule: "'@'.length > #1",
        message: "@ should be less than #1 characters",
      },
      {
        key: "NUMBERONLY",
        rule: "",
        reg_exp: "^[a-zA-Z0-9]",
        message: "@ is not a valid number",
      },
      {
        key: "CHARONLY",
        rule: "",
        reg_exp: "^[a-zA-Z]",
        message: "@ is not a valid text",
      },
      {
        key: "ALPHANUM",
        rule: "",
        reg_exp: "^[a-zA-Z0-9]",
        message: "@ is not a valid text",
      },
      {
        key: "SPLCHAR",
        rule: "",
        reg_exp: "^[a-zA-Z0-9._-!#$]",
        message: "@ is not a valid text",
      },
      {
        key: "EMAIL",
        rule: "'@'.length > #1",
        reg_exp:
          "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:.[a-zA-Z0-9-]+)*$",
        message: "@ is not valid",
      },
    ];

    const getRule = (key: string, val: string) => {
      let dset = RuleConfig;
      let result: any = [];
      dset.forEach((element: any) => {
        if (element.hasOwnProperty(key) && element[key] === val) {
          result.push(element);
        }
      });
      return result[0];
    };

    const replaceParams = (str: string, params: any): any => {
      for (let i = 1; i <= 10; i++) str = str.replaceAll("#" + i, params[i]);
      return str;
    };

    const validatePayload = (payload: any, ruleSet: any) => {
      let errors = new Array();
      let msgs: any = "";
      Object.keys(ruleSet).forEach((attr) => {
        let ruleSetList = ruleSet[attr];
        let rulesArray = ruleSetList["rules"];
        let attrDesc = ruleSetList["description"];
        rulesArray.forEach((r: any) => {
          let rule_key = r.split("-");
          // console.log(rule_key[0]);
          let rCfgRule = getRule("key", rule_key[0]);
          let rCfgExp = rCfgRule["reg_exp"] || "";
          let rSetRule = rCfgRule["rule"].replaceAll("@", payload[attr]);
          rSetRule = replaceParams(rSetRule, rule_key);
          let eResult: any = "Not Evaluated";
          let msg = "";
          try {
            if (
              rule_key[0] === "REQUIRED" ||
              (rule_key[0] != "REQUIRED" && payload[attr] != "")
            ) {
              msg = rCfgRule["message"];
              msg = replaceParams(msg, rule_key);
              msg = msg.replace("@", attrDesc);
              if (rCfgExp != "") {
                eResult = payload[attr].match(rCfgExp) ? false : true;
                // console.log("Regexp:" + eResult);
              } else {
                eResult = eval(rSetRule);
              }
              if (!eResult) msg = "";
            }
          } catch {
            eResult = "Failed";
          }
          let err = {
            attr: attr,
            rule: r,
            eval: rSetRule,
            method: rCfgExp != "" ? true : false,
            eval_result: eResult,
            message: msg,
          };
          if (msg != "") {
            errors.push(err);
            msgs = msgs + "" + msg;
          }
        });
      });
      return {
        errors: errors,
        result: errors.length === 0 ? false : true,
        message: msgs,
      };
    };
    const errors = ref({});
    watch(props, () => {
      if (props.validate) {
        show.value = false;
        let vldn = validatePayload(props.payload, props.rules);
        errors.value = vldn.errors;
        show.value = vldn.result;
        emit("result", vldn.result);
      }
    });

    const closeMe = () => {
      show.value = false;
    };
    return { closeMe, show, errors };
  },
});
</script>
<style lang="scss" scoped>
#myPopup {
  padding: 0.5em;
  background-color: $yellow-200;
  color: $red-800;
  font-size: 13px;
  display: block;

  ul > li {
    list-style-type: square;
    margin-left: 1em;
  }
}
// .errorbox {
//   display: absolute;
//   z-index: 500;
//   left: 0;
//   top: 0;
// }

//alert Transition
.msg-fade-enter-active,
.msg-leave-active {
  transition: all 0.65s ease;
}
.msg-fade-enter-from {
  opacity: 80%;
  transform: translateY(-100%);
}
.msg-fade-leave-to {
  opacity: 30%;
  transform: translateY(-100%);
}
.callout {
  position: fixed;
  top: 5em;
  right: 1em;
  max-width: 350px;
  box-shadow: 2px 3px 5px $gray-500;
  //border: 1px solid $black-500;
  width: 100%;
}

.callout-header {
  padding: 0.5em 1em;
  background: $red-800;
  font-size: 20px;
  color: $white;
}

.callout-container {
  padding: 1em;
  background-color: $yellow-100;
  color: black;
  display: grid;
  grid-template-columns: 1fr 5fr;
}

.closebtn {
  position: absolute;
  top: 5px;
  right: 15px;
  color: white;
  font-size: 30px;
  cursor: pointer;
}

.closebtn:hover {
  color: lightgrey;
}
</style>