<template>
  <div class="footer">
    <div id="wrapper">
      <!-- Menu -->
      <div id="main">
        <footer>
          <div class="page-grid-3">
            <div id="p-header" class="pg-item left">
              <h2>{{ APP_NAME }}</h2>
            </div>
            <div id="p-column1" class="pg-item left">
              <h3>PRODUCTS</h3>
              <div>
                <ul class="">
                  <li class="nav-item">
                    <a class="nav-link" href="#">Product 1</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Product 2</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Plans & Prices</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Frequently asked questions</a>
                  </li>
                </ul>
              </div>
            </div>
            <div id="p-column2" class="pg-item left">
              <h3>COMPANY</h3>
              <div>
                <ul class="">
                  <li class="nav-item">
                    <a class="nav-link" href="#">Product 1</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Product 2</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Plans & Prices</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Frequently asked questions</a>
                  </li>
                </ul>
              </div>
            </div>
            <div id="p-column3" class="pg-item left">
              <h3>SUPPORT</h3>
              <div>
                <ul class="">
                  <li class="nav-item">
                    <a class="nav-link" href="#">About us</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Job postings</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">News and articles</a>
                  </li>
                </ul>
              </div>
            </div>
            <div id="p-footer" class="footer-bottom pg-item center">
              Copyright 2021 K-Tools
            </div>
          </div>
        </footer>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent } from "vue";
import { APP_NAME } from "@/data/settings";
export default defineComponent({
  name: "Footer",
  props: {
    msg: String,
  },
  setup() {
    return {
      APP_NAME,
    };
  },
});
</script>

<style lang="scss" scoped>
footer {
  font-size: 1em;
  h3 {
    font-size: 1.1em;
  }
  li:before {
    content: "- ";
  }
}
.footer-bottom {
  color: $primary-700;
  border-top: 1px solid $primary-700;
  font-size:0.9em;
}
</style>

