<template>
  <div class="page-details error shadow-down-deep">
    <div class="m-container">
      <span class="title"> {{ $props.title }} - </span>
      <slot name="message"> </slot>
      <span class="close alert" @click="closeNav"
        ><fa class="icon-sm" icon="times"
      /></span>
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent, ref, watch } from "vue";

export default defineComponent({
  name: "Alert",
  props: {
    title: String,
    style: String,
  },
  emits: ["close"],
  setup(props, { emit }) {
    const closeNav = () => {
      emit("close");
    };

    const refresh = () => {
      if (props.title != "") {
        closeNav;
      }
    };
    watch(props, () => {
      refresh();
    });
    refresh();

    return {
      closeNav,
    };
  },
});
</script>

<style lang="scss">
.page-details {
  // overflow-x: hidden;
  // overflow-y: hidden;
  border: 1px solid $gray-500;
  box-shadow: inset 0px 0px 10px 1px rgba(71, 69, 69, 0.7);
  margin: auto;
  transition: 0.5s ease-in-out;
  display: block;
  text-align: center;
  position: relative;
  width: 100%;
  .m-container {
    margin-top: 0.3em;
    padding: 0.3em 0.3em;
  }
  .title {
    font-weight: 600;
  }

  slot {
    color: $white;
    text-align: center;
  }
  .close {
    position: absolute;
    top: 0;
    right: 0;
    background: transparent;
    cursor: pointer;
  }
  .close:hover {
    color: $primary-300;
  }
}

.alert {
  background-color: $primary-800;
  span {
    color: white;
  }
  .msg {
    color: $gray-200;
  }
}
.success {
  background-color: $green-800;
  span {
    color: white;
  }
  .msg {
    color: $gray-200;
  }
}
.info {
  background-color: $yellow-800;
  span {
    color: black;
  }
  .msg {
    color: $gray-200;
  }
}
.warning {
  background-color: $orange-800;
  span {
    color: white;
  }
  .msg {
    color: $gray-200;
  }
}
.error {
  background-color: $red-800;
  span {
    color: white;
  }
  .msg {
    color: $gray-200;
  }
}

//alert Transition
.msg-fade-enter-active,
.msg-leave-active {
  transition: all 0.65s ease;
}
.msg-fade-enter-from {
  opacity: 80%;
  transform: translateY(-100%);
}
.msg-fade-leave-to {
  opacity: 30%;
  transform: translateY(-100%);
}
</style>