<template>
  <div class="s-table-container">
    <div class="s-table-grid-tool">
      <div>
        <span><fa class="icon-sm" icon="th" /></span>
        <h3 style="display: inline; margin-left: 0.3em">Feedback Items</h3>
        <ContextMenu />
      </div>
      <div class="right">
        <a @click="toolClick('ADD', 0, {})" class="tool"
          ><fa class="icon-sm fa" icon="plus"
        /></a>
      </div>
    </div>
    <div class="">
      <div class="control-search">
        <div class="wrapper">
          <img
            class="search-icon"
            src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDU2Ljk2NiA1Ni45NjYiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDU2Ljk2NiA1Ni45NjY7IiB4bWw6c3BhY2U9InByZXNlcnZlIiB3aWR0aD0iMTZweCIgaGVpZ2h0PSIxNnB4Ij4KPHBhdGggZD0iTTU1LjE0Niw1MS44ODdMNDEuNTg4LDM3Ljc4NmMzLjQ4Ni00LjE0NCw1LjM5Ni05LjM1OCw1LjM5Ni0xNC43ODZjMC0xMi42ODItMTAuMzE4LTIzLTIzLTIzcy0yMywxMC4zMTgtMjMsMjMgIHMxMC4zMTgsMjMsMjMsMjNjNC43NjEsMCw5LjI5OC0xLjQzNiwxMy4xNzctNC4xNjJsMTMuNjYxLDE0LjIwOGMwLjU3MSwwLjU5MywxLjMzOSwwLjkyLDIuMTYyLDAuOTIgIGMwLjc3OSwwLDEuNTE4LTAuMjk3LDIuMDc5LTAuODM3QzU2LjI1NSw1NC45ODIsNTYuMjkzLDUzLjA4LDU1LjE0Niw1MS44ODd6IE0yMy45ODQsNmM5LjM3NCwwLDE3LDcuNjI2LDE3LDE3cy03LjYyNiwxNy0xNywxNyAgcy0xNy03LjYyNi0xNy0xN1MxNC42MSw2LDIzLjk4NCw2eiIgZmlsbD0iIzAwMDAwMCIvPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8L3N2Zz4K"
          />
          <input
            placeholder="Search"
            type="text"
            class="search"
            v-model="search"
            @keyup="searchData"
          />
        </div>
      </div>
    </div>
    <Loader v-if="isLoading" />
    <div class="s-table smart-table">
      <div class="s-tableHeading">
        <div class="s-tableRow">
          <template v-for="(col, hind) in dataView" :key="hind">
            <div
              class="s-tableHead"
              v-if="col.config.type != 'hidden'"
              @click="sortClick(col.attribute)"
            >
              {{ col.config.title }}
              <span class="icon-arrow">
                <fa
                  v-if="sort === col.attribute && sortOrder"
                  class="none"
                  icon="long-arrow-alt-up"
                />
                <fa
                  v-if="sort === col.attribute && !sortOrder"
                  class="none"
                  icon="long-arrow-alt-down"
                />
              </span>
            </div>
          </template>
          <div class="s-tableHead"><div class="center">Actions</div></div>
        </div>
      </div>
      <div class="s-tableBody">
        <template v-for="(row, rind) in data.slice(0, cRows) || []" :key="rind">
          <div class="s-tableRow">
            <template v-for="(col, cind) in dataView" :key="cind">
              <div class="s-tableCell" v-if="col.config.type != 'hidden'">
                <span class="small-title">{{ col.config.title }}</span>
                <div class="s-tableData">
                  <span
                    :class="
                      col.config.style +
                      ' ' +
                      col.attribute +
                      '_' +
                      row[col.attribute].toLowerCase().replaceAll(' ', '')
                    "
                    >{{ row[col.attribute] }}</span
                  >
                </div>
              </div>
            </template>
            <div class="s-tableCell toolcell">
              <a @click="toolClick('VIEW', rind, {})" class="tool">
                <fa class="icon-sm fa" icon="external-link-square-alt" /> </a
              >&nbsp;
              <a @click="toolClick('EDIT', rind, {})" class="tool">
                <fa class="icon-sm fa" icon="edit" /> </a
              >&nbsp;
              <a @click="toolClick('DELETE', rind, editPayload)" class="tool">
                <fa class="icon-sm fa red" icon="trash-alt" />
              </a>
            </div>
          </div>
        </template>
      </div>
    </div>
    <div class="smart-table outerTableFooter">
      <div class="tableFootStyle">
        <div class="links">
          <div class="count">
            <h6>Showing {{ cRows }} of {{ data.length || 0 }} Items</h6>
          </div>
          <a
            v-if="cRows != (data.length || 0)"
            class="active"
            @click="showMore"
          >
            Show More
          </a>
        </div>
      </div>
    </div>

    <div class="tfooter">
      <div>
        <div class="grid-container-3 htools">
          <div class="">
            <h5>Summary</h5>
            <span>Total Records : {{ data ? data.length : 0 || 0 }}</span>
          </div>
          <div class=""></div>
          <div class=""></div>
          <div class=""></div>
        </div>
      </div>
    </div>
    <Modal :show="isRowOpen" @close="isRowOpen = false">
      <SmartRow
        @close="isRowOpen = false"
        @save="saveRow"
        :data="data"
        :index="index"
        id="doc_id"
        :rkey="rkey"
        :type="type"
        :table="$props.table"
      />
    </Modal>
  </div>
</template>

<script lang="ts">
import {
  defineComponent,
  onBeforeMount,
  onBeforeUpdate,
  onMounted,
  onUpdated,
  reactive,
  ref,
  watch,
  watchEffect,
} from "vue";
import Loader from "@/components/common/Loader.vue"; // @ is an alias to /src
import { Utility } from "@/services/utility";
import { DATA_DICTIONARY } from "@/data/dictionary";
import Context from "@/components/common/Context.vue";
import SmartRow from "@/components/common/SmartRow.vue";
import Modal from "@/components/common/Modal.vue";
import ContextMenu from "@/components/common/ContextMenu.vue";
import { DATASET } from "@/data/mappings";
import moment from "moment";

export default defineComponent({
  name: "SmartTable",
  props: {
    data: Array,
    view: String,
    tools: String,
    id: String,
    table: String,
  },
  components: { Loader, Context, SmartRow, Modal, ContextMenu },
  emits: ["delete-row", "update-row", "insert-row"],
  setup(props, { emit }) {
    const showMenu = ref(false);
    const rkey = ref(0);
    const rSize = 2;
    const type = ref();
    const isRowOpen = ref(false);
    const isLoading = ref(true);
    let util = new Utility();
    const dataView = ref();
    dataView.value = [];
    const dataColumns = ref([{}]);
    const data = ref();
    let dataSelect = ref();
    const search = ref();
    const sort = ref();
    const sortOrder = ref(false);
    const index = ref();
    const cRows = ref();

    const refresh = () => {
      isLoading.value = true;
      data.value = props.data;
      cRows.value = rSize;
      cRows.value =
        cRows.value > data.value.length ? data.value.length : cRows.value;
      dataColumns.value = util.dictionary(
        props.table || "",
        Object.keys(data.value[0] || "").sort()
      );
      dataView.value = util.dictionary(
        props.table || "",
        Object.keys(data.value[0] || "").sort()
      );
      if ((props.view || "") != "") {
        let view = util.getDatasetByKeyVal(DATASET, "view", <string>props.view);
        dataColumns.value = <any[]>(
          util.dictionary(props.table || "", view.config.columns)
        );
        dataView.value = <any[]>(
          util.dictionary(props.table || "", view.config.columns)
        );
      }
    };

    const toolClick = (event: string, rind: number, payload: any) => {
      rkey.value = rkey.value + 1;
      dataSelect.value = data.value[rind];
      index.value = rind;
      type.value = event;
      if (event === "DELETE")
        emit("delete-row", dataSelect.value[props.id || ""]);
      else isRowOpen.value = true;
      refresh();
    };

    const sortClick = (attr: string) => {
      sortOrder.value = !sortOrder.value;
      sort.value = attr;
      data.value = util.arraySort(data.value, attr, sortOrder.value);
    };

    const saveRow = (type: string, rowId: any, payload: any) => {
      if (type === "EDIT") emit("update-row", rowId, payload);
      if (type === "ADD") emit("insert-row", rowId, payload);
      isRowOpen.value = false;
    };

    const showMore = () => {
      cRows.value = cRows.value + rSize;
      cRows.value =
        cRows.value > data.value.length ? data.value.length : cRows.value;
    };

    const searchData = () => {
      if (search.value.length > 2) {
        data.value = util.arrayFilterPatternMatch(
          <any[]>props.data,
          search.value
        );
      } else {
        data.value = props.data;
      }
    };
    watch(props, () => {
      data.value = props.data;
      refresh();
      rkey.value = rkey.value + 1;
    });

    onBeforeMount(() => {
      refresh();
    });

    onUpdated(() => {
      isLoading.value = false;
    });

    return {
      isLoading,
      data,
      dataColumns,
      dataView,
      toolClick,
      rkey,
      type,
      showMenu,
      dataSelect,
      isRowOpen,
      saveRow,
      searchData,
      search,
      sortClick,
      sort,
      sortOrder,
      index,
      cRows,
      showMore,
    };
  },
});
</script>
<style lang="scss">
div.smart-table {
  width: 100%;
  text-align: left;
  border-top: 2px solid $accent-900;
  //border: 1px solid $primary-300;
  //box-shadow:5px 5px 10px $primary-200;
}
.s-table.smart-table .s-tableCell,
.s-table.smart-table .s-tableHead {
  padding: 5px 10px;
}
.s-table.smart-table .s-tableBody .s-tableCell {
  //font-size: 15px;
  padding-top: 1em;
  padding-bottom: 1em;
}
.s-table.smart-table .s-tableHeading {
  background: $primary-500;
  background: -moz-linear-gradient(
    top,
    $primary-100 0%,
    $primary-200 66%,
    $primary-500 100%
  );
  background: -webkit-linear-gradient(
    top,
    $primary-100 0%,
    $primary-200 66%,
    $primary-500 100%
  );
  background: linear-gradient(
    to bottom,
    $primary-100 0%,
    $primary-200 66%,
    $primary-500 100%
  );
}
.s-table.smart-table .s-tableHeading .s-tableHead {
  //font-size: 15px;
  font-weight: bold;
  color: $black-900;
  text-align: left;
  padding: 5px 10px;
}
.smart-table .tableFootStyle {
  //font-size: 15px;
  font-weight: bold;
  color: $black-800;
}
.smart-table .tableFootStyle {
  //font-size: 15px;
  background: $primary-100;
}
.smart-table .tableFootStyle .links {
  text-align: center;
  padding: 0.5em;
}
.smart-table .tableFootStyle .links a {
  display: inline-block;
  background: $accent-800;
  color: $white;
  padding: 5px 10px 2px;
  border-radius: 5px;
  text-decoration: none;
  margin: auto;
}
.smart-table .tableFootStyle .links a:hover {
  background: $accent-900;
  transition: 0.2s ease-in-out;
}
.smart-table.outerTableFooter {
  border-top: none;
}
.smart-table.outerTableFooter .tableFootStyle {
  padding: 5px;
}
.s-tableHead {
  cursor: pointer;
}
.s-tableHead:hover {
  cursor: pointer;

  opacity: 60%;
}
.s-table {
  display: table;
}
.s-tableRow {
  display: table-row;
}
.s-tableHeading {
  display: table-header-group;
}
.s-tableCell,
.s-tableHead {
  display: table-cell;
  border-bottom: 1px solid $primary-100;
}
.s-tableHeading {
  display: table-header-group;
}
.s-tableFoot {
  display: table-footer-group;
}
.s-tableBody {
  display: table-row-group;
}
.toolcell {
  text-align: center;
  min-width: 180px;
}
.small-title {
  display: none;
  color: $black-800;
  font-weight: 600;
  font-size: 14px;
}
div.count {
  width: 100%;
  text-align: center;
  margin-bottom: 0.5em;
  h6 {
    font-size: 0.9em;
  }
}
.control-search {
  .wrapper {
    position: relative;
    display: flex;
    min-width: 100px;
  }
  .search {
    // border: 1px solid grey;
    height: 25px;
    width: 100%;
    padding: 2px 23px 2px 30px;
    outline: 0;
    background-color: $accent-100;
    border: 0px;
  }
  .search-icon {
    position: absolute;
    top: 10px;
    left: 8px;
    width: 15px;
  }
  .clear-icon {
    position: absolute;
    top: 15px;
    right: 8px;
    width: 12px;
    cursor: pointer;
    visibility: hidden;
  }
  .search:hover,
  .search:focus {
    background-color: $accent-100;
  }
}
.icon-arrow {
  color: $accent-900;
}
.s-table-grid-tool {
  * {
    padding: 0;
    margin: 0;
  }
  margin-top: 1em;
  margin-bottom: 1em;
  display: grid;
  grid-template-columns: 3fr 1fr;

  span {
    padding: 5px;
    color: $primary-600;
  }
}
@media only screen and (max-width: 1024px), (max-device-width: 1024px) {
  .s-tableHeading {
    display: none;
  }
  .small-title {
    display: block;
  }
  .s-table.smart-table .s-tableBody .s-tableCell {
    //font-size: 15px;
    padding-top: 0.5em;
    padding-bottom: 0.5em;
  }

  .s-tableCell,
  .s-tableHead {
    display: block;
  }
  .toolcell {
    background: $accent-200;
    width: 100%;
    border-bottom: 2px solid $primary-500;
  }
}
</style>