<template>
  <div class="tile-container left">
    <template v-for="(tile, ind) in data" :key="ind">
      <div v-if="!tile.disabled" class="tile left">
        <!-- {{ tile }} -->
        <router-link :to="tile.link">
          <div class="tile-inner left">
            <span class="tile-icon"
              ><fa class="icon-lg" :icon="tile.icon" />
            </span>
            <span class="tile-text"> {{ tile.title }} </span>
          </div>
        </router-link>
      </div>
      <div v-if="tile.disabled" class="tile-disable">
        <!-- {{ tile }} -->
        <span>
          <div class="tile-inner left">
            <span class="tile-icon"><fa class="icon-lg" icon="code" /> </span>
            <span class="tile-text"> {{ tile.title }} </span>
          </div>
        </span>
      </div>
    </template>
  </div>
</template>
<script lang="ts">
import { inject, defineComponent, ref, watch, reactive } from "vue";
export default defineComponent({
  name: "Tiles",
  props: { data: Object },
  setup(props) {
    const selectedObj = ref();
    watch(props, () => {});
    const close = () => {};
    return { selectedObj };
  },
});
</script>

<style lang="scss" scoped>
.tile-container {
  padding: 0.5em;
  a {
    text-decoration: none;
  }
}
.tile {
  cursor: pointer;
  display: inline-block;
  margin: 0.25em;
  padding: 0.25em;
  -webkit-transition: 0.3s ease-in-out;
  transition: 0.3s ease-in-out;
  .tile-inner {
    width: 120px;
    height: 150px;
    background: $white;
    border-radius: 10px;
    padding: 1em;
    border: 1px solid $primary-500;
    box-shadow: 6px 6px 8px 0 rgba(0, 0, 0, 0.25),
      -4px -4px 6px 0 rgba(255, 255, 255, 0.3);
  }
  .tile-text {
    display: block;
    font-weight: bold;
    color: $primary-700;
    font-size: 0.9em;
    word-wrap: none;
  }
  .tile-icon {
    padding-top: 1em;
    display: block;
    color: $accent-700;
  }
  .disable {
    color: $primary-300;
  }
}

.tile:hover {
  // opacity: 0.5;
  right: -60px;
  .tile-inner {
    background: $accent-800;
    -webkit-transition: 0.3s ease-in-out;
    transition: 0.3s ease-in-out;
  }
  .tile-text {
    display: block;
    color: $white;
    transition: 0.3s ease-in-out;
  }
  .tile-icon {
    display: block;
    color: $accent-200;
    transition: 0.3s ease-in-out;
  }
}
.tile-disable {
  display: inline-block;
  margin: 0.25em;
  padding: 0.25em;
  -webkit-transition: 0.3s ease-in-out;
  transition: 0.3s ease-in-out;
  .tile-inner {
    width: 120px;
    height: 150px;
    background: $white;
    border-radius: 10px;
    padding: 1em;
    border: 1px solid $primary-200;
    box-shadow: 6px 6px 8px 0 rgba(0, 0, 0, 0.25),
      -4px -4px 6px 0 rgba(255, 255, 255, 0.3);
  }
  .tile-text {
    display: block;
    font-weight: bold;
    color: $primary-500;
    font-size: 0.9em;
    word-wrap: none;
  }
  .tile-icon {
    padding-top: 1em;
    display: block;
    color: $primary-300;
  }
}

// .tile:hover > div {
//   left: 0;
// }
// .tile:hover > div a i {
//   left: 0;
// }
// .tile:hover a:first-child i {
//   -webkit-transition-delay: 0.1s;
//   transition-delay: 0.1s;
// }
</style>