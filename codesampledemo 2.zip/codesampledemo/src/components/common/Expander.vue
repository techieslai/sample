<template>
  <!-- The Modal -->
  <div :class="style">
    <div class="box-grid link-button collapsible" @click="show = !show">
      <div class="title-bar">
        <span class="span-icon"
          ><fa class="t-icon" :icon="$props.icon || 'th'" /></span
        ><span class="t-title">{{ $props.title }}</span>
      </div>
      <div class="title-bar right">
        <span class="span-icon"
          ><fa v-if="!show" class="t-icon" icon="chevron-right"
        /></span>
        <span class="span-icon"
          ><fa v-if="show" class="t-icon" icon="chevron-down"
        /></span>
      </div>
    </div>
    <transition name="fade" v-if="show">
      <div class="content">
        <slot />
      </div>
    </transition>
  </div>
</template>
<script lang="ts">
import { defineComponent, ref, watch } from "vue";
export default defineComponent({
  name: "Expander",
  emits: ["close"],
  props: { title: String, icon: String, cstyle: String },
  setup(props, { emit }) {
    const show = ref(false);
    const style = ref("");
    style.value = "content-wrapper" + " " + props.cstyle || "";
    const close = () => {
      emit("close");
    };
    return { show, close, style };
  },
});
</script>

<style lang="scss">
.content-wrapper {
  margin-bottom: 1em;
  width: 100%;
}
/* Style the button that is used to open and close the collapsible content */
.collapsible {
  margin-top: 1em;
  background-color: $accent-900;
  color: $white;
  cursor: pointer;
  padding: 0.4em 0.8em;
  width: 100%;
  border: none;
  text-align: left;
  font-weight: bold;
  display: grid;
  grid-template-columns: 5fr 1fr;
  border-bottom: 2px solid $accent-900;
}
.title-bar {
  margin-top: 0.3em;
  position: relative;
  .t-title {
    position: absolute;
    margin-top: -0.1em;
  }
}
.span-icon {
  .t-icon {
    width: 15px;
    height: 15px;
    display: inline;
    margin-right: 0.5em;
  }
}

/* Add a background color to the button if it is clicked on (add the .active class with JS), and when you move the mouse over it (hover) */
.active,
.collapsible:hover {
  background-color: $accent-800;
}

/* Style the collapsible content. Note: hidden by default */
.content {
  padding: 1em;
  border: 1px solid $accent-900;
  overflow: hidden;
  background-color: $white;
}

@keyframes expand {
  0% {
    transform: scaleX(0);
    opacity: 50%;
  }
  100% {
    transform: scaleX(1);
    opacity: 90%;
  }
}

.fade-enter-active {
  transition: opacity 1.5s;
}
.fade-leave-active {
  opacity: 0;
}
.fade-enter,
.fade-leave-to {
  opacity: 0;
}
</style>