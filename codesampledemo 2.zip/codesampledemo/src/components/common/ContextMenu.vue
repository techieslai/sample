<template>
  <!-- The Modal -->
  <div class="context-container">
    <div @mouseleave="show = false">
      <a class="context link-tool" @click="show = !show"
        ><fa class="icon-sm" :icon="show ? 'angle-down' : 'angle-right'"
      /></a>
      <transition name="fade" v-if="show">
      <div class="context" @click="show = false" >
        <div id="contextmenu">
          <a href="">Add</a>
          <a href="">Edit</a>
          <hr />
          <a href="">Delete</a>
          <hr />
          <a class="ticked" href="">Selectable option</a>
          <a class="ticked" href=""
            >This option has been intentionally truncated</a
          >
        </div>
      </div>
      </transition>
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent, ref, watch } from "vue";
export default defineComponent({
  name: "ContextMenu",
  emits: ["close"],
  props: {},
  setup(props, { emit }) {
    const show = ref(false);
    const close = () => {
      emit("close");
    };
    return { show, close };
  },
});
</script>

<style lang="scss">
/* The Modal (background) */
.modal {
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  background-color: rgb(0, 0, 0); /* Fallback color */
  background-color: rgba(0, 0, 0, 0.6); /* Black w/ opacity */
}
.scrollable {
  overflow-y: auto;
  width: 100%;
  height: 100%;
  position: fixed; /* Stay in place */
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto; /* 15% from the top and centered */
  padding: 20px;
  border: 1px solid #888;
  width: 50%; /* Could be more or less, depending on screen size */
}

/* The Close Button */
.close {
  color: rgb(250, 250, 250);
  float: right;
  font-size: 28px;
  font-weight: bold;
  margin-right: 1em;
  margin-top: 1em;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}

// .show {
//   background: linear-gradient(
//     90deg,
//     $page-bgcolor,
//     $yellow-900,
//     $white,
//     $yellow-900,
//     $page-bgcolor
//   );
//   width: 100%;
//   height: 5px;
//   animation: expand 1s linear infinite;
// }

.context-container {
  display: "inline";
}

#contextmenu {
  position: absolute;
  background-color: $primary-100;
  padding: 5px;
  font-size: 13px;
  z-index: 1000;
  box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.35);
  padding: 0.5em 0 0.5em 0;
  display: block;
}

#contextmenu hr {
  border: none;
  border-bottom: 1px solid $primary-300;
}

#contextmenu a {
  display: block;
  text-decoration: none;
  color: $primary-900;
  padding: 0.5em 2em 0.5em 0.75em;
  max-width: 13em;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
#contextmenu a:hover {
  background-color: $accent-900;
  color: $white;
}

#contextmenu a::before {
  content: "";
  margin-right: 0.75em;
  width: 0.5em;
  height: 1em;
  display: inline-block;
}

#contextmenu a.ticked::before {
  content: "\2713";
}
#contextmenu a.unticked::before {
  content: "\2610";
}

/* Animatinons */
@-webkit-keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@-webkit-keyframes fadeOut {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}

@keyframes fadeOut {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}

.is-fadingIn {
  -webkit-animation: fadeIn 0.1s ease-out;
  animation: fadeIn 0.1s ease-out;
  opacity: 1;
  display: block;
}
.is-fadingOut {
  -webkit-animation: fadeOut 0.1s ease-out;
  animation: fadeOut 0.1s ease-out;
  opacity: 0;
  display: block;
}

.close-container {
  position: absolute;
  width: 100%;
  margin-top: 3em;
  text-align: right;
  .close {
    color: white;
    // background: $black;
    padding: 10px;
    width: 30px;
    text-align: center;
    height: 50px;
  }
}
@media only screen and (max-width: 760px),
  (min-device-width: 768px) and (max-device-width: 1024px) {
  /* The Modal (background) */
  .modal {
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    background-color: rgb(0, 0, 0); /* Fallback color */
    background-color: rgba(0, 0, 0, 0.4); /* Black w/ opacity */
  }

  /* Modal Content/Box */
  .modal-content {
    background-color: #fefefe;
    margin: 25% auto; /* 15% from the top and centered */
    padding: 20px;
    //border: 1px solid #888;
    width: 95%; /* Could be more or less, depending on screen size */
    overflow-y: auto;
  }
  .close-container {
    position: absolute;
    width: 100%;
    margin-top: 2em;
    text-align: right;
    .close {
      color: white;
    }
  }
}

@keyframes expand {
  0% {
    transform: scaleX(0);
    opacity: 50%;
  }
  100% {
    transform: scaleX(1);
    opacity: 90%;
  }
}

.fade-enter-active{
        transition: opacity 1.5s;
    }
    .fade-leave-active {
        opacity: 0;
    }
    .fade-enter, .fade-leave-to {
        opacity: 0;
    }


</style>