<template>
  <nav class="">
    <template v-for="(link, ind) in data" :key="ind">
      <div :class="link.class || ''">
        <div class="nav-link">
          <router-link to="link.link"> {{ link.title }} </router-link>
        </div>
        <div
          class="expand right"
          v-if="link.links && link.expand"
          @click="clickLink(link.id)"
        >
          <fa class="icon-sm1" icon="chevron-down" />
        </div>
        <div
          class="expand right"
          v-if="link.links && !link.expand"
          @click="clickLink(link.id)"
        >
          <fa class="icon-sm1" icon="chevron-right" />
        </div>
      </div>
      <template v-for="(slink, sind) in link.links" :key="sind">
        <div :class="slink.class" v-if="link.expand">
          <div class="nav-link">
            <router-link to="slink.link"> {{ slink.title }} </router-link>
          </div>
        </div>
      </template>
    </template>
  </nav>
</template>
<script lang="ts">
import {
  defineComponent,
  ref,
  watch,
  computed,
  onBeforeMount,
  onUpdated,
} from "vue";
export default defineComponent({
  name: "Context",
  props: {
    style: String,
    menu: Array,
  },

  setup(props, { emit }) {
    const show = ref(false);
    const data = ref();
    data.value = props.menu || [];
    const style = computed(() => {
      return {
        top: "2em",
        left: "10em",
      };
    });
    const refresh = (id: number) => {
      for (let i = 0; i < data.value.length || 0; i++) {
        let el = data.value[i];
        el.class = "nav-grid";
        el.expand = false;
        if (el.id === id) {
          el.class = "nav-grid select";
        }
        if (el.links) {
          for (let j = 0; j < el.links.length || 0; j++) {
            let sel = el.links[j];
            sel.class = "nav-grid-slink";
            if (sel.id === id) {
              sel.class = "nav-grid-slink select";
            }
          }
        }
      }
    };
    const clickLink = (id: number) => {
      for (let i = 0; i < data.value.length || 0; i++) {
        let el = data.value[i];
        el.class = "nav-grid";
        if (el.id === id) {
          el.class = "nav-grid select";
          el.expand = !el.expand;
        }
        if (el.links) {
          for (let j = 0; j < el.links.length || 0; j++) {
            let sel = el.links[j];
            sel.class = "nav-grid-slink";
            if (sel.id === id) {
              sel.class = "nav-grid-slink select";
            }
          }
        }
      }
    };

    watch(props, () => {
      data.value = props.menu;
    });

    onBeforeMount(() => {
      refresh(1);
    });

    return { data, style, show, clickLink };
  },
});
</script>

<style lang="scss" scoped>
.nav-grid {
  display: grid;
  grid-template-columns: 4fr 1fr;
  border-left: 2px solid $white;
  font-size: 0.9em;
  font-weight: 500;
  padding-top: 0em 0.5em;
  width: 100%;
  border-bottom: 1px solid $primary-100;
  color: $accent-900;
  div {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    padding: 0.1em 0.5em;
    cursor: pointer;
    a {
      text-decoration: none;
      color: $accent-900;
    }
  }
}
.nav-grid:hover {
  background-color: $gray-100;
  border-left: 2px solid $accent-800;
  transition: 0.2s ease-in-out;
  a {
    text-decoration: none;
    color: $accent-800;
  }
}

.nav-grid-slink {
  display: grid;
  grid-template-columns: 4fr 1fr;
  border-left: 2px solid $white;
  font-size: 0.9em;
  font-weight: 500;
  padding-top: 0em 0.5em;
  background-color: $white;
  color: $accent-900;
  border-bottom: 1px solid $primary-100;

  div {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    padding: 0.1em 0.5em;
    cursor: pointer;
    a {
      text-decoration: none;
      color: $accent-900;
    }
  }
}
.nav-grid-slink:hover {
  background-color: $gray-100;
  color: $accent-800;
  transition: 0.2s ease-in-out;
  border-left: 2px solid $accent-500;
  a {
    text-decoration: none;
    color: $accent-800;
  }
}
.expand {
}

.select {
  background-color: $accent-200;
  color: $accent-800;
  transition: 0.2s ease-in-out;
  border-left: 2px solid $accent-800;
  a {
    text-decoration: none;
    color: $accent-800;
  }
}

// .nav-link {
//   text-decoration: none;
//   margin-bottom: 0.1em;
//   transition: 0.2s ease-in-out;
//   font-size: 1em;
//   font-weight: 600;
//   width: 100%;
//   white-space: nowrap;
//   overflow: hidden;
//   text-overflow: ellipsis;
// }
// // .nav-link:hover,
// .nav-link:active {
//   display: block;
//   background-color: $accent-800;
//   color: $white;
// }
// .nav-slink {
//   margin-left: 0.5em;
//   width: 9.5em;
//   background-color: $white;
// }
.hide {
  display: none;
}
.show {
  display: block;
}
</style>