<template>
  <div class="loader-container">
    <transition name="fade">
      <div v-if="show" class="show"></div> </transition
    >
  </div>
</template>
<script lang="ts">
import { defineComponent, ref, watch } from "vue";
export default defineComponent({
  name: "Loader",
  props: {
    style: String,
    show: Boolean,
  },
  setup(props, { emit }) {
    const type = ref();
    const show = ref(true);
    watch(props, () => {
      type.value = props.style;
      show.value = props.show;
    });
    return { type, show };
  },
});
</script>

<style lang="scss">
.loader-container {
  background: $page-bgcolor;
  width: 100%;
  height: 3px;
}
.show {
  background: linear-gradient(
    90deg,
    $page-bgcolor,
    $accent-900,
    $accent-900,
    $page-bgcolor
  );
  width: 100%;
  height: 3px;
  animation: expand 1s linear infinite;
}

@keyframes expand {
  0% {
    transform: scaleX(0);
    opacity: 50%;
  }
  100% {
    transform: scaleX(1);
    opacity: 90%;
  }
}
</style>