<template>
  <div class="sidenav">
    <div class="grid-container-tool">
      <div class="left">
        <h5 class="title">{{ $props.title || "" }}</h5>
      </div>
      <div class="closebtn" @click="closeNav">
        <a @click="closeNav"><fa icon="chevron-left" class="normal" /></a>
      </div>
    </div>
    <div class="grid user-info" v-if="user.email && $props.title === 'PROFILE'">
      <div class="circle center">
        <h4>{{ user.name || "" }}</h4>
      </div>
      <div class="user-info left">
        <h5>{{ user.fname || "" }}</h5>
        <span><fa class="icon-sm" icon="envelope" /> {{ user.email }} </span>
      </div>
    </div>
    <nav class="links">
      <ul>
        <template v-for="item in menu" :key="item.id">
          <li @click="closeNav">
            <template v-if="item.link != 'logout'">
              <router-link :to="item.link">
                <fa :icon="item.icon" class="normal" />
                <span>{{ item.title }}</span></router-link
              >
            </template>
            <template v-if="item.link === 'logout'">
              <a class="button" click="item.link" @click="logout">
                <fa :icon="item.icon" class="normal" />
                <span>{{ item.title }}</span>
              </a>
            </template>
          </li>
        </template>
      </ul>
    </nav>
  </div>
</template>
<script lang="ts">
import { defineComponent, ref, watch } from "vue";
import {
  PROFILE_MENU,
  PROFILE_LOGIN,
  MAIN_MENU,
  MAIN_USER_MENU,
  AUTH_USER,
} from "@/data/settings";

import router from "@/router";
import store from "@/store";

export default defineComponent({
  name: "SideNav",
  props: {
    title: String,
    role: String,
  },
  emits: ["close", "alert", "hRefresh"],
  setup(props, { emit }) {
    const mySidenav: any = ref({});
    const result = ref();
    const user = ref();
    const menu = ref({});
    const closeNav = () => {
      mySidenav.value["width"] = "0px";
      emit("close");
    };

    const logout = async () => {
      result.value = await store.dispatch("logout");
      router.push("/login");
      emit("hRefresh");
    };

    const refresh = () => {
      user.value = store.getters.profile;
      if (props.title === "MAIN MENU" && props.role === "") {
        menu.value = MAIN_MENU;
      }
      if (props.title === "MAIN MENU" && props.role === "user") {
        menu.value = MAIN_USER_MENU;
      }
      if (props.title === "PROFILE" && props.role === "") {
        menu.value = PROFILE_LOGIN;
      }
      if (props.title === "PROFILE" && props.role === "user") {
        menu.value = PROFILE_MENU;
      }
    };

    watch(props, () => {
      refresh();
    });
    refresh();
    return {
      mySidenav,
      closeNav,
      menu,
      logout,
      user,
    };
  },
});
</script>

<style lang="scss" scoped>
.sidenav {
  height: 100%;
  width: 310px;
  position: fixed;
  z-index: 20;
  top: 0;
  left: 0;
  background-color: $sidemenu-bgcolor;
  overflow-x: hidden;
  transition: 0.5s;
  //padding-top: 1.5em;
  border-right: 1px solid $primary-200;
  color: $sidemenu-text-color;
  li,
  a {
    border-bottom: 0px;
    margin: 0;
    padding: 0;
  }
}
.grid {
  display: grid;
  grid-template-columns: 2fr 8fr;
  margin: auto;
  width: 100%;
  height: 5.5em;
}
.user-info {
  padding: 0.5em;
  h5 {
    color: $white;
    font-size: 1em;
    padding: 0;
    margin: 0;
  }
  span {
    color: $accent-300;
    font-size: 1em;
  }
  h4 {
    color: $accent-900;
    font-size: 1.4em;
    margin-top: 0.6em;
  }
  background: $accent-900;
}
.circle {
  background: $accent-400;
  border-radius: 50%;
  width: 60px;
  height: 60px;
  h4 {
    color: $accent-900;
  }
}
.grid-container-tool {
  border-bottom: 1px solid $gray-100;
  height: 4em;
}
.sidenav li {
  display: block;
  height: 3em;
  padding-top: 2em;
}

.sidenav a {
  margin: auto;
  padding-left: 1em;
  text-decoration: none;
  text-shadow: none;
  font-size: 15px;
  color: $sidemenu-text-color;
  display: block;
  transition: 0.1s;
  span {
    margin-left: 1em;
  }
}

.sidenav a:hover {
  color: $accent-900;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 0;
  margin-right: 2em;
  margin-top: 1.3em;
}

// .icon {
//   margin-right: 1em;
//   margin-top: 0.5em;
//   cursor: pointer;
//   color: $sidemenu-text-color;
//   opacity: 80%;
//   font-size: 20px;
// }
// .icon:hover {
//   text-align: center;
//   cursor: pointer;
//   color: $sidemenu-text-color;
//   opacity: 100%;
//   width: 30px;
//   height: 30px;
// }
ul {
  list-style: none;
}
.title {
  padding: 0.5em 1em;
  font-size: 1.2em;
  color: $sidemenu-title-color;
}

@media screen and (max-height: 450px) {
  .sidenav {
    padding-top: 1em;
  }
  .sidenav a {
    font-size: 13px;
    width: 300px;
  }
}
</style>