<template>
  <transition name="fade">
    <div key="1" :class="type" v-if="show">
      <div class="content-info">
        <h4>{{ $props.title }}</h4>
        <div class="content-text">
          <span v-if="$props.closable" class="close" @click="show = false"
            >&times;</span
          >
          <slot> </slot>
        </div>
      </div>
    </div>
  </transition>
</template>
<script lang="ts">
import { defineComponent, ref, watch } from "vue";
export default defineComponent({
  name: "InfoBar",
  props: {
    type: String,
    closable: Boolean,
    title: String,
  },
  setup(props, { emit }) {
    const type = ref();
    const show = ref(true);
    type.value = "content-wrapper " + (props.type || "") + "-info";
    return { type, show };
  },
});
</script>

<style lang="scss" scoped>
.content-wrapper {
  position: relative;
  margin-top: 1em;
  margin-bottom: 1em;
  width: 100%;
  //   border-top-right-radius: 10px;
  //   border-bottom-right-radius: 10px;
  padding: 1em 2em;
  color: black;
  font-size: 1em;
  .conent-info,
  .conent-info > li {
    padding: 0.5em 1em;
    width: 100%;
    background: transparent;
  }
  .content-text {
    margin-top: 1em;
    margin-bottom: 0.5em;
  }
}

.error-info {
  border-left: 5px solid $red-500;
  background: $red-200;
}

.warning-info {
  border-left: 5px solid $orange-500;
  background: $orange-200;
}

.info-info {
  border-left: 5px solid $yellow-500;
  background: $yellow-200;
}
.normal-info {
  border-left: 5px solid $primary-300;
  background: $primary-100;
}

.primary-info {
  border-left: 5px solid $primary-500;
  background: $primary-200;
}
.accent-info {
  border-left: 5px solid $accent-200;
  background: $accent-100;
}

.close {
  position: absolute;
  top: 0;
  right: 0;
  margin-top: 0.3em;
  margin-right: -0.2em;
  border-radius: 10px;
  width: 40px;
  height: 40px;
  color: black;
  font-size: 2em;
  cursor: pointer;
}
.close:hover {
  color: $accent-800;
}

.fade-enter-active {
  transition: opacity 1.5s;
}
.fade-leave-active {
  opacity: 0;
}
.fade-enter,
.fade-leave-to {
  opacity: 0;
}
</style>