<template>
  <div id="wrapper">
    <!-- Menu -->
    <div id="main">
      <!-- page -->
      <article class="page">
        <header>
          <div class="title">
            <h1>Help</h1>
            <p>
              Created to help improving your productivity so that you can focus
              on other important things
            </p>
          </div>
          <div class="meta">
            <router-link to="/" class="tool-link"
              ><fa class="icon-sm" icon="home"
            /></router-link>
          </div>
        </header>

        <p>
          Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl.
          Sed mattis nunc id lorem euismod placerat. Vivamus porttitor magna
          enim, ac accumsan tortor cursus at. Phasellus sed ultricies mi non
          congue ullam corper. Praesent tincidunt sed tellus ut rutrum. Sed
          vitae justo condimentum, porta lectus vitae, ultricies congue gravida
          diam non fringilla.
        </p>
        <p>
          Nunc quis dui scelerisque, scelerisque urna ut, dapibus orci. Sed
          vitae condimentum lectus, ut imperdiet quam. Maecenas in justo ut
          nulla aliquam sodales vel at ligula. Sed blandit diam odio, sed
          fringilla lectus molestie sit amet. Praesent eu tortor viverra lorem
          mattis pulvinar feugiat in turpis. Class aptent taciti sociosqu ad
          litora torquent per conubia nostra, per inceptos himenaeos. Fusce
          ullamcorper tellus sit amet mattis dignissim. Phasellus ut metus
          ligula. Curabitur nec leo turpis. Ut gravida purus quis erat pretium,
          sed pellentesque massa elementum. Fusce vestibulum porta augue, at
          mattis justo. Integer sed sapien fringilla, dapibus risus id, faucibus
          ante. Pellentesque mattis nunc sit amet tortor pellentesque, non
          placerat neque viverra.
        </p>

        <article>
          <div class="page-grid-12">
            <div id="p-header" class="pg-item left">
              <h2>Frequently Asked Questions</h2>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid
                praesentium, cumque quo commodi voluptatum culpa neque pariatur
                perferendis quos? Harum, quasi sunt pariatur cupiditate mollitia
                excepturi distinctio ullam iure tempora?
              </p>
              <router-link to="/" class="link-button">Some Link</router-link
              >&nbsp;&nbsp;
            </div>
            <div id="p-column1" class="pg-item left">
              <h3>Categories</h3>

              <nav>
                <Context />
              </nav>
            </div>
            <div id="p-column2" class="pg-item left">
              <h3></h3>
              <p>
                <ExpanderList title="How does it Work?">
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                  Molestiae, aliquid recusandae. Ad dolore placeat repellendus
                  similique, ducimus natus atque voluptatum nesciunt repellat.
                  Aliquam tempora distinctio repellendus earum sed porro
                  pariatur!
                </ExpanderList>
                <ExpanderList title="How to use the tools?">
                  Sit amet consectetur, adipisicing elit. Aliquid consequuntur
                  aliquam corrupti nulla molestiae adipisci dolores magni aut,
                  dicta quibusdam enim cum suscipit esse doloribus iure culpa
                  harum. Quas, ipsam!
                </ExpanderList>
                <ExpanderList title="How to contact Support?">
                  Ipsum dolor sit amet consectetur adipisicing elit. Aliquam
                  autem dolores, veritatis repellendus nostrum totam deserunt ab
                  ex nam aliquid voluptatum quidem dolorum perspiciatis deleniti
                  voluptatibus dicta ullam reprehenderit. Quas?
                </ExpanderList>
              </p>
            </div>

            <div id="p-footer" class="pg-item"></div>
          </div>
        </article>

        <footer>
          <!-- <ul class="stats">
            <li><a href="#">General</a></li>
            <li><a href="#" class="icon solid fa-heart">28</a></li>
            <li><a href="#" class="icon solid fa-comment">128</a></li>
          </ul> -->
        </footer>
      </article>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";
import Context from "@/components/common/Context.vue";
import ExpanderList from "@/components/common/ExpanderList.vue";
import TabView from "@/components/common/TabView.vue";
import Tab from "@/components/common/Tab.vue";

export default defineComponent({
  name: "Help",
  props: {
    title: String,
  },
  components: {
    TabView,
    Tab,
    ExpanderList,
    Context,
  },
});
</script>

