export const DATA_DICTIONARY = [
  {
    attribute: "insert_dt",
    config: {
      title: "Created On",
      data_type: "date",
      input_type: "date",
      display_type: "label",
      type: "hidden",
      length: 20,
      icon: "text",
    },
  },
  {
    attribute: "insert_user",
    config: {
      title: "Created By",
      data_type: "text",
      input_type: "user",
      display_type: "label",
      type: "user",
      length: 20,
      icon: "text",
    },
  },
  {
    attribute: "update_dt",
    config: {
      title: "Updated On",
      data_type: "date",
      input_type: "date",
      display_type: "label",
      type: "hidden",
      length: 20,
      icon: "text",
    },
  },
  {
    attribute: "update_user",
    config: {
      title: "Updated By",
      data_type: "text",
      input_type: "email",
      display_type: "label",
      type: "hidden",
      length: 20,
      icon: "text",
    },
  },
  {
    attribute: "title",
    config: {
      title: "Title",
      data_type: "text",
      input_type: "text",
      display_type: "label",
      type: "normal",
      length: 20,
      icon: "text",
    },
  },

  {
    attribute: "category",
    config: {
      title: "Category",
      data_type: "text",
      input_type: "list",
      display_type: "label",
      type: "normal",
      length: 20,
      icon: "text",
    },
  },

  {
    attribute: "feedback.category",
    config: {
      title: "Category-Table",
      data_type: "text",
      input_type: "list",
      display_type: "label",
      type: "normal",
      length: 20,
      icon: "text",
    },
  },

  {
    attribute: "description",
    config: {
      title: "Description",
      data_type: "text",
      input_type: "text",
      display_type: "label",
      type: "normal",
      length: 20,
      icon: "text",
    },
  },
  {
    attribute: "status",
    config: {
      title: "Status",
      data_type: "text",
      input_type: "text",
      display_type: "label",
      type: "normal",
      length: 20,
      icon: "text",
      style: "badge",
    },
  },

  {
    attribute: "password",
    config: { title: "Password", type: "text", length: 20, icon: "text" },
  },
  {
    attribute: "cPassword",
    config: {
      title: "Confirm Password",
      type: "text",
      display_type: "label",
      length: 20,
      icon: "text",
    },
  },
  {
    attribute: "email",
    config: { title: "E-Mail", type: "email", length: 20, icon: "text" },
  },
  {
    attribute: "rememberMe",
    config: { title: "Remember", type: "check", length: 20, icon: "text" },
  },
  {
    attribute: "fname",
    config: { title: "Full Name", type: "text", length: 20, icon: "text" },
  },
  {
    attribute: "doc_id",
    config: {
      title: "Document ID",
      type: "hidden",
      length: 20,
      icon: "text",
    },
  },
];
