export const APP_NAME = "K-TOOLS";
export const APP_CODE = "KTOOLS";
export const APP_HERO = "Your home for Innovation and Productivity";
export const APP_HERO_DESC = "Find and use the tools for more productivity";

export const AUTH_TOKEN = APP_CODE + "_token";
export const AUTH_EMAIL = APP_CODE + "_email";
export const AUTH_NAME = APP_CODE + "_name";
export const AUTH_KEY = APP_CODE + "_key";
export const AUTH_USER = APP_CODE + "_user";

export const API_URL = "https://fakerapi.it/api/v1/";
export const DB_URL = "user";

export const PROFILE_MENU = [
  {
    id: 1,
    title: "Dashboard",
    link: "/dashboard",
    icon: "th",
  },
  {
    id: 1,
    title: "Change Password",
    link: "/changepassword",
    icon: "asterisk",
  },
  {
    id: 2,
    title: "Settings",
    link: "/settings",
    icon: "cog",
  },
  {
    id: 3,
    title: "Feedback",
    link: "/feedback",
    icon: "rss",
  },
  {
    id: 4,
    title: "Logout",
    link: "logout",
    icon: "power-off",
  },
];
export const PROFILE_LOGIN = [
  {
    id: 1,
    title: "Login",
    link: "/login",
    icon: "lock",
  },
  {
    id: 2,
    title: "Register",
    link: "/register",
    icon: "user",
  },
  {
    id: 3,
    title: "Forgot Password",
    link: "/forgotpassword",
    icon: "asterisk",
  },
];
export const MAIN_MENU = [
  {
    id: 1,
    title: "Home",
    link: "/",
    icon: "home",
  },
  {
    id: 2,
    title: "Features",
    link: "/features",
    icon: "server",
  },
  {
    id: 3,
    title: "Explore",
    link: "/explore",
    icon: "route",
  },
  {
    id: 4,
    title: "Help",
    link: "/help",
    icon: "question",
  },
];

export const MAIN_USER_MENU = [
  {
    id: 1,
    title: "Home",
    link: "/",
    icon: "home",
  },
  {
    id: 2,
    title: "Features",
    link: "/features",
    icon: "server",
  },
  {
    id: 3,
    title: "Explore",
    link: "/explore",
    icon: "route",
  },
  {
    id: 4,
    title: "Help",
    link: "/help",
    icon: "question",
  },
];

export const APP_TILES = [
  {
    id: 0,
    title: "Forms",
    link: "/apps/pmanager",
    icon: "desktop",
  },
  {
    id: 1,
    title: "Keypad",
    link: "/apps/pmanager",
    icon: "star",
  },
  {
    id: 2,
    title: "To Dos",
    link: "/apps",
    icon: "square",
    disabled: true,
  },
  {
    id: 3,
    title: "Contacts",
    link: "/apps",
    icon: "square",
    disabled: true,
  },

  {
    id: 4,
    title: "Go Links",
    link: "/apps",
    icon: "book",
    disabled: true,
  },
  {
    id: 5,
    title: "Games",
    link: "/games",
    icon: "th",
    disabled: false,
  },
];
export const BOOK_TILES = [
  {
    id: 1,
    title: "Lamb in the Darkness",
    link: "/stories",
  },
  {
    id: 2,
    title: "Missing Dog Found",
    link: "/stories",
  },
  {
    id: 3,
    title: "Lazy Boy in the Dark",
    link: "/stories",
  },
  {
    id: 4,
    title: "Ready for Raise",
    link: "/stories",
  },
];

export const FEATURE_MENU = [
  {
    id: 1,
    title: "Vue 3",
    link: "#vue",
    icon: "home",
  },
  {
    id: 2,
    title: "Cloud",
    link: "",
    icon: "server",
    links: [
      {
        id: 2.1,
        title: "Firebase",
        link: "#fire",
        icon: "route",
      },
      {
        id: 2.2,
        title: "AWS",
        link: "#aws",
        icon: "question",
      },
    ],
  },
  {
    id: 3,
    title: "JavaScript",
    link: "#js",
    icon: "route",
  },
  {
    id: 4,
    title: "Frontend",
    link: "#css",
    icon: "question",
    links: [
      {
        id: 4.1,
        title: "HTML",
        link: "#html",
        icon: "route",
      },
      {
        id: 4.2,
        title: "CSS",
        link: "#css",
        icon: "question",
      },
    ],
  },
];
