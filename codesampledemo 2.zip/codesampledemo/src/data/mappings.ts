export const DATASET = [
  {
    view: "users",
    config: {
      columns: ["fname", "email"],
    },
  },
  {
    view: "users1",
    config: {
      columns: ["fname", "email"],
    },
  },
  {
    view: "users2",
    config: {
      columns: ["fname", "email"],
    },
  },
];
