export const FIREBASE_CONFIG = {
apiKey: "AIzaSyC4CtTvL7h8Q-SDpW03m9gxDoog9_2kTJM",
  authDomain: "ktls-8ba81.firebaseapp.com",
  projectId: "ktls-8ba81",
  storageBucket: "ktls-8ba81.appspot.com",
  messagingSenderId: "295585404894",
  appId: "1:295585404894:web:06b7ea676f3dd89dd76f4f",
  measurementId: "G-WB8G2F8G3M"
};

