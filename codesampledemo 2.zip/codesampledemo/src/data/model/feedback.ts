export const feedback = [
  {
    data: [
      {
        attribute: "id",
        config: {
          title: "id",
          data_type: "text",
          input_type: "text",
          display_type: "label",
          type: "hidden",
          length: 20,
          icon: "text",
        },
      },

      {
        attribute: "category",
        config: {
          title: "Category",
          data_type: "date",
          input_type: "date",
          display_type: "label",
          type: "hidden",
          length: 20,
          icon: "text",
        },
      },
      {
        attribute: "title",
        config: {
          title: "Title",
          data_type: "date",
          input_type: "date",
          display_type: "label",
          type: "hidden",
          length: 20,
          icon: "text",
        },
      },
      {
        attribute: "description",
        config: {
          title: "Details",
          data_type: "textarea",
          input_type: "textarea",
          display_type: "label",
          type: "hidden",
          length: 20,
          icon: "text",
        },
      },
      {
        attribute: "details",
        config: {
          title: "Details",
          data_type: "textarea",
          input_type: "textarea",
          display_type: "label",
          type: "hidden",
          length: 20,
          icon: "text",
        },
      },
      {
        attribute: "status",
        config: {
          title: "Status",
          data_type: "textarea",
          input_type: "textarea",
          display_type: "label",
          type: "hidden",
          length: 20,
          icon: "text",
          default: "Open",
        },
      },
    ],
  },
];
