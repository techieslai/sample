import axios from "axios";

const requestOptions = {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: ""
};

const state = {
  users: [],
};

const getters = {
  usersList: (state: any) => state.users,
};

const actions = {
  async fetchUsers({ commit }: any) {
    const response = await axios.get("http://localhost:3000/users");
    commit("setUsers", response.data);
  },
  async addUsers({ commit }: any, user: any) {
    const response = await axios.post("http://localhost:3000/users", user);
    commit("addNewUser", response.data);
  },
  async deleteUser({ commit }: any, id: any) {
    await axios.delete(`http://localhost:3000/users/${id}`);
    commit("removeUser", id);
  },
};

const mutations = {
  setUsers: (state: any, users: any) => (state.users = users),
  addNewUser: (state: any, user: any) => state.users.unshift(user),
  removeUser: (state: any, id: any) => (
    state.users.filter((user: any) => user.id !== id),
    state.users.splice((user: any) => user.id, 1)
  ),
};

export default {
  state,
  getters,
  actions,
  mutations,
};
