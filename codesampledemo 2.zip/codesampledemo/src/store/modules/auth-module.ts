import { reactive, ref } from "vue";
import { FIREBASE_CONFIG } from "@/data/k-tools";
import { } from "@/data/k-tools";
import firebase from "firebase/app";
// Required for side-effects
import "firebase/auth";
import "firebase/database";
import "firebase/firestore";
import "firebase/storage";
import { AUTH_USER } from "@/data/settings";
import { FDBUtility } from "@/services/fdbutility";

const fdb = !firebase.apps.length
  ? firebase.initializeApp(FIREBASE_CONFIG)
  : firebase.app();

const state = {
  user: null,
  isInitialized: false,
  isLoggedIn: false,
  error: null,
};

const getters = {
  isLoggedIn: (state: any) => {
    return state.isLoggedIn;
  },
  isAdmin: (state: any) => {
    if (state.isLoggedIn && state.user.user["email"] === "admin@email.com")
      return true;
    else return false;
  },
  profile: (state: any) => {
    let profile = {
      name: "",
      fname: "",
      email: "",
      last_login: "",
      token: "",
    };
    if (state.isLoggedIn) {
      profile.email = state.user.user["email"];
      let str = state.user.info["fname"].toUpperCase().split(" ");
      profile.name =
        (str[0] + '').toUpperCase().substring(0, 1) +
        (str[1] + '').toUpperCase().substring(0, 1);
      profile.fname = state.user.info["fname"];
    }
    return profile;
  },
  error: (state: any) => {
    return state.error;
  },
};

const actions = {
  // async login_good({ commit }: any, payload: any) {
  //   console.log(payload.email + "-" + payload.password);
  //   await fdb
  //     .auth()
  //     .signInWithEmailAndPassword(payload.email, payload.password)
  //     .then(
  //       (user) => {
  //         console.log("User Loggedin - " + user);
  //         commit("setUser", user);
  //       },
  //       (error) => {
  //         commit("throwError", error);
  //       }
  //     );
  // },

  async login({ commit }: any, payload: any) {
    const response = await fdb
      .auth()
      .signInWithEmailAndPassword(payload.email, payload.password)
      .then(async (user) => {
        let usr = <any>(
          await new FDBUtility("users", false).getbyKeyVal(
            "email",
            payload.email
          )
        );
        usr[0].last_login = new Date();
        await new FDBUtility("userQueue", false).add(usr[0]);
        usr = { info: usr[0] };
        commit("setUser", { ...user, ...usr });
      })
      .catch((error) => {
        commit("throwError", error);
        throw error;
      });
  },
  async register({ commit }: any, payload: any) {
    let response = await fdb
      .auth()
      .createUserWithEmailAndPassword(payload.email, payload.password)
      .then(async (user) => {
        delete payload.password;
        delete payload.cpassword;
        payload["last_login"] = "";
        payload["last_logout"] = "";
        await new FDBUtility("users", false).add(payload);
        payload["code1"] = payload.email;
        payload["code2"] = payload.fname;
        payload["scode"] = "";
        await new FDBUtility("keypads", false).add(payload);
      })
      .catch((error) => {
        commit("throwError", error);
        throw error;
      });
  },
  async logout({ commit }: any) {
    const response = await fdb
      .auth()
      .signOut()
      .then(() => {
        state.user = null;
      });
    commit("removeUser");
  },
  async forgotPassword({ commit }: any, payload: any) {
    const response = await fdb
      .auth()
      .sendPasswordResetEmail(payload.email)
      .then(() => {
        state.user = null;
      });
  },
  async chanhePassword({ commit }: any, payload: any) {
    const response = await fdb
      .auth()
      .sendPasswordResetEmail(payload.email)
      .then(() => {
        state.user = null;
      });
  },
  async authCheck({ commit }: any) {
    return new Promise((resolve, reject) => {
      !state.isInitialized &&
        fdb.auth().onAuthStateChanged(async (_user) => {
          commit("authUser", _user);
          resolve(true);
        });
    });
  },
};

const mutations = {
  setUser: (state: any, user: any) => {
    state.user = user;
    state.isLoggedIn = true;
  },
  authUser: (state: any, user: any) => {
    state.user = user;
    state.isLoggedIn = true;
    state.isInitialized = true;
  },
  removeUser: (state: any) => {
    state.user = null;
    state.isLoggedIn = false;
  },
  throwError: (state: any, error: any) => {
    state.error = error;
  },
};

export default {
  state,
  getters,
  actions,
  mutations,
};
