import { createStore } from "vuex";
import usersModule from "../store/modules/user-module";
import authModule from "../store/modules/auth-module";
import createPersistedState from "vuex-persistedstate";

export default createStore({
  state: {},
  mutations: {},
  actions: {},
  modules: { usersModule, authModule },
  plugins: [createPersistedState()]
});
